// Verificação rápida do projeto: versão do Node, sintaxe do servidor e arquivos do app.
// Uso: npm run check
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
let fail = 0;
const ok = (m) => console.log("  ✔", m);
const bad = (m) => { console.log("  ✘", m); fail++; };

const [major, minor] = process.versions.node.split(".").map(Number);
console.log("Node.js");
if (major > 22 || (major === 22 && minor >= 13)) ok(`versão ${process.versions.node}`);
else bad(`versão ${process.versions.node} (precisa 22.13 ou mais nova)`);

console.log("Sintaxe do servidor");
const walk = (d) => fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]));
for (const f of walk(path.join(root, "server")).filter((f) => f.endsWith(".js"))) {
  try { execFileSync(process.execPath, ["--check", f], { stdio: "pipe" }); ok(path.relative(root, f)); }
  catch (e) { bad(`${path.relative(root, f)}: ${e.stderr}`); }
}

console.log("Arquivos do app");
const pub = path.join(root, "public");
const html = fs.readFileSync(path.join(pub, "index.html"), "utf8");
const refs = [...html.matchAll(/(?:src|href)="\/([^"?#]+)"/g)].map((m) => m[1]);
const js = fs.readdirSync(path.join(pub, "assets")).find((f) => f.startsWith("index-") && f.endsWith(".js"));
const bundle = fs.readFileSync(path.join(pub, "assets", js), "utf8");
for (const m of bundle.matchAll(/\.\/((?:hls|lamejs)-[\w-]+\.js)/g)) refs.push(`assets/${m[1]}`);
for (const i of JSON.parse(fs.readFileSync(path.join(pub, "manifest.json"), "utf8")).icons) refs.push(i.src.replace(/^\//, ""));
for (const r of [...new Set(refs)]) (fs.existsSync(path.join(pub, r)) ? ok(r) : bad(`faltando: public/${r}`));

console.log("Configuração");
fs.existsSync(path.join(root, ".env.example")) ? ok(".env.example") : bad("faltando .env.example");
fs.existsSync(path.join(root, ".env")) ? ok(".env (configurado)") : console.log("  • .env ainda não criado (opcional; o instalador cria a partir do .env.example)");

console.log(fail ? `\n${fail} problema(s) encontrado(s).` : "\nTudo certo.");
process.exit(fail ? 1 : 0);
