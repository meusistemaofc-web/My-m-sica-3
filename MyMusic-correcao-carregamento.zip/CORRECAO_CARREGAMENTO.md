# Correção direcionada — carregamento após login

Foi corrigido o bundle compilado do frontend. Na função de conclusão de login, o estado global `loading` não era desligado explicitamente. A tela principal depende desse estado para deixar de exibir o logotipo com o spinner.

A correção adiciona `o(!1)` na transição de login bem-sucedido, antes de atualizar o usuário. O arquivo JavaScript recebeu um novo nome para evitar reutilização do bundle antigo. O cache do Service Worker foi versionado de `mm-v2` para `mm-v3`, para solicitar os novos arquivos.

**Limitação:** este pacote contém o frontend compilado, não o código-fonte React/TypeScript original. A alteração corrige o defeito identificado no bundle, mas precisa ser validada no navegador após a implantação.
