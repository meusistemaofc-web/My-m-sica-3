/*
 * My Music service worker: keeps the interface available offline.
 *
 * - Pages (navigations) are network-first; offline (or when the network takes too long) they
 *   fall back to the cached app shell, which opens the same app as online (the library comes
 *   from the copy the app keeps in IndexedDB).
 * - Built assets (/assets/*, hashed and immutable) are cache-first.
 * - Icons, favicon, the manifest and the app icons are served from cache and refreshed in the background.
 * - Album covers (GET /api/covers/:key, immutable random keys) are cache-first in a cache that
 *   survives new versions ("mm-covers"), so covers stay visible offline.
 * - The rest of /api is never cached or intercepted: sessions, library data and audio
 *   streaming (HTTP Range) always go straight to the server.
 * - Push notifications (Web Push, sent by the server): shown on "push"; a click opens or
 *   focuses the app on the notification's link and reports the click.
 */
const VERSION = "mm-v3";
const SHELL = `${VERSION}-shell`;
const ASSETS = `${VERSION}-assets`;
const FONTS = `${VERSION}-fonts`;
/** Not versioned: covers never change for a key, so they are kept across updates. */
const COVERS = "mm-covers";
const MAX_ASSETS = 80;
const MAX_COVERS = 1500;
/** A navigation waits this long for the network before opening the cached shell. */
const PAGE_TIMEOUT_MS = 4000;
const STATIC = ["/favicon.svg", "/icon-192.png", "/icon-512.png", "/apple-touch-icon.png", "/manifest.json"];

/** Caches the app shell and every script/style it references. */
async function cacheShell() {
  const cache = await caches.open(SHELL);
  const res = await fetch("/", { cache: "no-cache" });
  if (!res.ok) return;
  const html = await res.clone().text();
  await cache.put("/", res);
  const assets = [...html.matchAll(/(?:src|href)="(\/assets\/[^"]+)"/g)].map((m) => m[1]);
  const assetCache = await caches.open(ASSETS);
  await Promise.all(assets.map((url) => assetCache.add(url).catch(() => {})));
  await Promise.all(STATIC.map((url) => cache.add(url).catch(() => {})));
}

self.addEventListener("install", (event) => {
  event.waitUntil(cacheShell().catch(() => {}).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => !k.startsWith(`${VERSION}-`) && k !== COVERS).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

async function trim(cacheName, max) {
  const cache = await caches.open(cacheName);
  const keys = await cache.keys();
  await Promise.all(keys.slice(0, Math.max(0, keys.length - max)).map((k) => cache.delete(k)));
}

async function networkFirstPage(request) {
  const cached = await caches.match("/", { cacheName: SHELL });
  const network = fetch(request).then((res) => {
    if (res.ok && (res.headers.get("content-type") || "").includes("text/html")) {
      const copy = res.clone();
      caches.open(SHELL).then((c) => c.put("/", copy));
    }
    return res;
  });
  const fallback = () =>
    cached || new Response("<h1>My Music</h1><p>Você está offline.</p>", { headers: { "Content-Type": "text/html; charset=utf-8" } });
  if (!cached) return network.catch(fallback);
  // With a cached shell, a slow connection doesn't keep the app from opening.
  const timeout = new Promise((resolve) => setTimeout(() => resolve(cached), PAGE_TIMEOUT_MS));
  return Promise.race([network.catch(fallback), timeout]);
}

async function cacheFirst(request, cacheName, max = MAX_ASSETS) {
  const cached = await caches.match(request, { cacheName });
  if (cached) return cached;
  const res = await fetch(request);
  if (res.ok) {
    const copy = res.clone();
    caches.open(cacheName).then((c) => c.put(request, copy).then(() => trim(cacheName, max)));
  }
  return res;
}

async function staleWhileRevalidate(request, cacheName) {
  const cached = await caches.match(request, { cacheName });
  const network = fetch(request)
    .then((res) => {
      if (res.ok || res.type === "opaque") {
        const copy = res.clone();
        caches.open(cacheName).then((c) => c.put(request, copy));
      }
      return res;
    })
    .catch(() => cached);
  return cached || network;
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  if (url.origin !== self.location.origin) {
    if (url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com") {
      event.respondWith(staleWhileRevalidate(request, FONTS));
    }
    return;
  }

  if (url.pathname.startsWith("/api/covers/")) {
    event.respondWith(cacheFirst(request, COVERS, MAX_COVERS));
    return;
  }
  if (url.pathname.startsWith("/api/branding/icon/")) {
    event.respondWith(staleWhileRevalidate(request, SHELL));
    return;
  }
  if (url.pathname.startsWith("/api/")) return;

  if (request.mode === "navigate") {
    event.respondWith(networkFirstPage(request));
    return;
  }
  if (url.pathname.startsWith("/assets/")) {
    event.respondWith(cacheFirst(request, ASSETS));
    return;
  }
  if (STATIC.includes(url.pathname) || url.pathname === "/manifest.webmanifest") {
    event.respondWith(staleWhileRevalidate(request, SHELL));
  }
});

// ---------------------------------------------------------------------------
// Push notifications

self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { body: event.data ? event.data.text() : "" };
  }
  const title = data.title || "My Music";
  const options = {
    body: data.body || "",
    icon: data.icon || "/icon-192.png",
    tag: data.tag || undefined,
    lang: "pt-BR",
    data: { url: data.url || "/", deliveryId: data.deliveryId || null },
  };
  if (data.image) options.image = data.image;
  if (data.actionText) options.actions = [{ action: "open", title: data.actionText }];
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const { url = "/", deliveryId = null } = event.notification.data || {};
  const target = new URL(url, self.location.origin);
  const internal = target.origin === self.location.origin;

  event.waitUntil(
    (async () => {
      if (deliveryId) {
        fetch("/api/push/opened", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ id: deliveryId }),
        }).catch(() => {});
      }
      if (internal) {
        const windows = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
        const open = windows.find((c) => new URL(c.url).origin === self.location.origin);
        if (open) {
          // The app navigates with its router, so the player keeps playing.
          open.postMessage({ type: "mm:navigate", url: target.pathname + target.search + target.hash });
          return open.focus();
        }
      }
      return self.clients.openWindow(target.href);
    })(),
  );
});

// The browser rotated the subscription: store the new one (the session cookie identifies the account).
self.addEventListener("pushsubscriptionchange", (event) => {
  const old = event.oldSubscription;
  event.waitUntil(
    (async () => {
      const options = old && old.options ? old.options : null;
      if (!options || !options.applicationServerKey) return;
      const sub = event.newSubscription || (await self.registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: options.applicationServerKey }));
      await fetch("/api/push/subscription", {
        method: "POST",
        credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscription: sub.toJSON(), oldEndpoint: old ? old.endpoint : undefined, device: "" }),
      });
    })().catch(() => {}),
  );
});
