// Testes de segurança e robustez. Rode com: npm test
import { test, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { startMocks, startServer, client } from "./helpers.mjs";

let mocks, srv, c;
before(async () => {
  mocks = await startMocks();
  srv = await startServer(mocks.port, undefined, { RATE_LIMIT: "on" });
  c = client(srv.base);
  await c.post("/api/auth/setup", { email: "admin@gmail.com", password: "senha-forte-123" });
});
after(async () => { await srv.stop(); await mocks.close(); fs.rmSync(srv.dataDir, { recursive: true, force: true }); });

test("bloqueia tentativas repetidas de login", async () => {
  const anon = client(srv.base);
  const codes = [];
  for (let i = 0; i < 12; i++) codes.push((await anon.post("/api/auth/login", { email: "admin@gmail.com", password: "errada" })).status);
  assert.ok(codes.slice(0, 10).every((s) => s === 401), codes.join(","));
  assert.equal(codes.at(-1), 429);
});

test("recusa corpo grande demais e JSON inválido", async () => {
  const big = await fetch(srv.base + "/api/auth/signup", { method: "POST", headers: { "Content-Type": "application/json" }, body: Buffer.alloc(27 * 1024 * 1024, 32) });
  assert.equal(big.status, 413);
  const bad = await fetch(srv.base + "/api/support/tickets", { method: "POST", headers: { "Content-Type": "application/json", cookie: c.cookie }, body: "{x" });
  assert.equal(bad.status, 400);
  assert.equal((await fetch(srv.base + "/api/health")).status, 200, "o servidor continua de pé");
});

test("não expõe arquivos internos por caminhos manipulados", async () => {
  for (const p of ["/%2e%2e/server/config.js", "/..%2f.env", "/assets/..%2f..%2fpackage.json", "/api/covers/..%2f..%2fmymusic.db", "/api/files/..%2fsecret.key"]) {
    const r = await fetch(srv.base + p);
    const t = await r.text();
    assert.doesNotMatch(t, /process\.env|APP_SECRET|SQLite format|"scripts"/, p);
  }
});

test("chaves secretas nunca voltam para o navegador", async () => {
  await c.put("/api/admin/email", { from: "x <a@b.com>", apiKey: "re_segredo_123" });
  const e = await c.get("/api/admin/email");
  assert.equal(e.data.hasApiKey, true);
  assert.ok(!JSON.stringify(e.data).includes("re_segredo_123"));
  const s = await c.get("/api/auth/session");
  assert.ok(!JSON.stringify(s.data).includes("password"));
  const users = await c.get("/api/admin/users");
  assert.ok(!JSON.stringify(users.data).includes("scrypt"));
});

test("cookie de sessão protegido", async () => {
  // (o login por este IP já foi bloqueado no teste de força bruta; o cadastro usa outro limite)
  const r = await fetch(srv.base + "/api/auth/signup", { method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email: "cookie@teste.com", password: "senha-forte-123", confirm: "senha-forte-123" }) });
  assert.equal(r.status, 200);
  const ck = r.headers.get("set-cookie") || "";
  assert.match(ck, /HttpOnly/);
  assert.match(ck, /SameSite=Lax/);
});
