// Utilitários dos testes: sobe o servidor num diretório temporário e simula Mercado Pago e Resend.
import { spawn } from "node:child_process";
import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const FIX = path.join(ROOT, "test", "fixtures");

/** Simulador da API do Mercado Pago e do Resend. */
export function startMocks() {
  const payments = new Map();
  const emails = [];
  let n = 5000;
  const server = http.createServer(async (req, res) => {
    let raw = "";
    for await (const c of req) raw += c;
    const body = raw ? JSON.parse(raw) : {};
    const send = (s, d) => { res.writeHead(s, { "Content-Type": "application/json" }); res.end(JSON.stringify(d)); };
    const auth = req.headers.authorization || "";
    if (req.url.startsWith("/resend")) {
      if (!auth.includes("re_")) return send(401, { message: "invalid key" });
      if (req.url === "/resend/emails") { emails.push(body); return send(200, { id: "em_" + emails.length }); }
      return send(200, { data: [] });
    }
    if (!/TEST-|APP_USR-/.test(auth)) return send(401, { message: "invalid access token" });
    if (req.url === "/users/me") return send(200, { id: 777, nickname: "LOJA_TESTE", site_id: "MLB" });
    if (req.url === "/v1/payment_methods") return send(200, [{ id: "pix", payment_type_id: "bank_transfer", status: "active" }]);
    if (req.method === "POST" && req.url === "/v1/payments") {
      const id = ++n;
      const p = { id, status: "pending", status_detail: "pending_waiting_transfer", payment_method_id: body.payment_method_id,
        payment_type_id: "bank_transfer", transaction_amount: body.transaction_amount, currency_id: "BRL",
        external_reference: body.external_reference, date_of_expiration: body.date_of_expiration,
        point_of_interaction: { transaction_data: { qr_code: `000201PIXTESTE${id}`, qr_code_base64: null } } };
      payments.set(String(id), p);
      return send(201, p);
    }
    const m = req.url.match(/^\/v1\/payments\/(\d+)$/);
    if (m && req.method === "GET") return payments.has(m[1]) ? send(200, payments.get(m[1])) : send(404, { message: "not found" });
    if (m && req.method === "PUT") { const p = payments.get(m[1]); Object.assign(p, body); return send(200, p); }
    send(404, { message: "?" });
  });
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => {
    const port = server.address().port;
    resolve({
      port, payments, emails,
      approve: (id) => Object.assign(payments.get(String(id)), { status: "approved", status_detail: "accredited", date_approved: new Date().toISOString() }),
      close: () => new Promise((r) => server.close(r)),
    });
  }));
}

/** Sobe uma instância do My Music com dados temporários. */
export async function startServer(mockPort, dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "mymusic-test-")), extraEnv = {}) {
  const port = 20000 + Math.floor(Math.random() * 20000);
  const child = spawn(process.execPath, ["--no-warnings", "server/start.js"], {
    cwd: ROOT,
    env: { ...process.env, PORT: String(port), HOST: "127.0.0.1", DATA_DIR: dataDir, MM_TEST: "1", RATE_LIMIT: "off",
      MP_API_BASE: `http://127.0.0.1:${mockPort}`, RESEND_API_BASE: `http://127.0.0.1:${mockPort}/resend`, PUBLIC_URL: "", APP_SECRET: "teste", ...extraEnv },
    stdio: ["ignore", "pipe", "pipe"],
  });
  let log = "";
  child.stdout.on("data", (d) => (log += d));
  child.stderr.on("data", (d) => (log += d));
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 100; i++) {
    try { if ((await fetch(base + "/api/health")).ok) break; } catch {}
    await new Promise((r) => setTimeout(r, 100));
  }
  return { base, dataDir, child, log: () => log, stop: () => new Promise((r) => { child.once("exit", r); child.kill("SIGTERM"); }) };
}

/** Cliente HTTP com cookie de sessão. */
export function client(base) {
  let cookie = "";
  const req = async (method, url, body, headers = {}) => {
    const isBuf = Buffer.isBuffer(body);
    const res = await fetch(base + url, {
      method,
      headers: { ...(cookie ? { cookie } : {}), ...(body !== undefined && !isBuf ? { "Content-Type": "application/json" } : {}), ...headers },
      body: body === undefined ? undefined : isBuf ? body : JSON.stringify(body),
      redirect: "manual",
    });
    const set = res.headers.get("set-cookie");
    if (set) cookie = set.split(";")[0].endsWith("=") ? "" : set.split(";")[0];
    const type = res.headers.get("content-type") || "";
    const data = type.includes("json") ? await res.json() : Buffer.from(await res.arrayBuffer());
    return { status: res.status, data, headers: res.headers };
  };
  return {
    get: (u, h) => req("GET", u, undefined, h), post: (u, b, h) => req("POST", u, b ?? {}, h), put: (u, b, h) => req("PUT", u, b ?? {}, h),
    patch: (u, b) => req("PATCH", u, b ?? {}), del: (u, b) => req("DELETE", u, b),
    get cookie() { return cookie; }, set cookie(v) { cookie = v; },
  };
}

/** Envia uma música MP3 pelo mesmo fluxo do app (em partes). */
export async function uploadSong(admin, file, meta) {
  const buf = fs.readFileSync(file);
  const s = await admin.post("/api/songs", { mimeType: "audio/mpeg", size: buf.length, duration: 12, ...meta });
  if (s.status !== 200) throw new Error("criar música: " + JSON.stringify(s.data));
  const size = s.data.chunkSize;
  for (let i = 0; i * size < buf.length; i++) {
    const r = await admin.put(`/api/songs/${s.data.id}/chunks/${i}`, buf.subarray(i * size, (i + 1) * size), { "Content-Type": "application/octet-stream" });
    if (r.status !== 200) throw new Error("parte: " + JSON.stringify(r.data));
  }
  const done = await admin.post(`/api/songs/${s.data.id}/complete`, { publish: true });
  if (done.status !== 200) throw new Error("concluir: " + JSON.stringify(done.data));
  return done.data;
}
