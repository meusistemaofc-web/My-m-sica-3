// Banco de dados SQLite embutido no Node (node:sqlite, Node >= 22.13), sem dependências externas.
import { DatabaseSync } from "node:sqlite";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";

fs.mkdirSync(config.dataDir, { recursive: true });
export const db = new DatabaseSync(path.join(config.dataDir, "mymusic.db"));

db.exec(`
PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  data TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  device TEXT,
  ip TEXT,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS docs (
  coll TEXT NOT NULL,
  id TEXT NOT NULL,
  owner INTEGER,
  data TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (coll, id)
);
CREATE INDEX IF NOT EXISTS docs_owner ON docs(coll, owner);
CREATE TABLE IF NOT EXISTS kv (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);

const now = () => new Date().toISOString();

// ---------- key/value (configurações) ----------
export function kvGet(key, fallback = null) {
  const row = db.prepare("SELECT value FROM kv WHERE key = ?").get(key);
  if (!row) return fallback;
  try { return JSON.parse(row.value); } catch { return fallback; }
}
export function kvSet(key, value) {
  db.prepare("INSERT INTO kv(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value")
    .run(key, JSON.stringify(value));
  return value;
}
export function kvDel(key) { db.prepare("DELETE FROM kv WHERE key = ?").run(key); }

// ---------- documentos genéricos ----------
const parse = (row) => (row ? { ...JSON.parse(row.data), id: row.id } : null);

export const docs = {
  get(coll, id) {
    return parse(db.prepare("SELECT id, data FROM docs WHERE coll = ? AND id = ?").get(coll, String(id)));
  },
  list(coll, owner) {
    const rows = owner === undefined
      ? db.prepare("SELECT id, data FROM docs WHERE coll = ? ORDER BY created_at DESC").all(coll)
      : db.prepare("SELECT id, data FROM docs WHERE coll = ? AND owner IS ? ORDER BY created_at DESC").all(coll, owner);
    return rows.map(parse);
  },
  put(coll, id, data, owner = null) {
    const t = now();
    const existing = db.prepare("SELECT created_at FROM docs WHERE coll = ? AND id = ?").get(coll, String(id));
    const doc = { ...data, id: String(id) };
    if (existing) {
      db.prepare("UPDATE docs SET data = ?, owner = COALESCE(?, owner), updated_at = ? WHERE coll = ? AND id = ?")
        .run(JSON.stringify(doc), owner, t, coll, String(id));
    } else {
      db.prepare("INSERT INTO docs(coll, id, owner, data, created_at, updated_at) VALUES(?, ?, ?, ?, ?, ?)")
        .run(coll, String(id), owner, JSON.stringify(doc), data.createdAt || t, t);
    }
    return doc;
  },
  patch(coll, id, partial) {
    const cur = docs.get(coll, id);
    if (!cur) return null;
    return docs.put(coll, id, { ...cur, ...partial, updatedAt: now() });
  },
  del(coll, id) {
    return db.prepare("DELETE FROM docs WHERE coll = ? AND id = ?").run(coll, String(id)).changes > 0;
  },
  delWhere(coll, predicate) {
    for (const d of docs.list(coll)) if (predicate(d)) docs.del(coll, d.id);
  },
};

// ---------- usuários ----------
export function rowToUser(row) {
  if (!row) return null;
  const data = JSON.parse(row.data || "{}");
  return {
    id: row.id,
    email: row.email,
    role: row.role,
    displayName: data.displayName || row.email.split("@")[0],
    name: data.displayName || row.email.split("@")[0],
    access: data.access || "approved",
    approvedNotice: !!data.approvedNotice,
    blocked: !!data.blocked,
    createdAt: row.created_at,
    settings: data.settings || {},
    avatarUrl: data.avatarUrl || null,
    _data: data,
  };
}
export const users = {
  count: () => db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
  byId: (id) => rowToUser(db.prepare("SELECT * FROM users WHERE id = ?").get(Number(id))),
  byEmail: (email) => rowToUser(db.prepare("SELECT * FROM users WHERE email = ?").get(String(email).toLowerCase())),
  hash: (id) => db.prepare("SELECT password_hash FROM users WHERE id = ?").get(Number(id))?.password_hash,
  all: () => db.prepare("SELECT * FROM users ORDER BY id").all().map(rowToUser),
  create({ email, passwordHash, role = "user", data = {} }) {
    const r = db.prepare("INSERT INTO users(email, password_hash, role, data, created_at) VALUES(?, ?, ?, ?, ?)")
      .run(String(email).toLowerCase(), passwordHash, role, JSON.stringify(data), now());
    return users.byId(r.lastInsertRowid);
  },
  updateData(id, partial) {
    const u = users.byId(id);
    if (!u) return null;
    const data = { ...u._data, ...partial };
    db.prepare("UPDATE users SET data = ? WHERE id = ?").run(JSON.stringify(data), Number(id));
    return users.byId(id);
  },
  setPassword(id, passwordHash) { db.prepare("UPDATE users SET password_hash = ? WHERE id = ?").run(passwordHash, Number(id)); },
  setRole(id, role) { db.prepare("UPDATE users SET role = ? WHERE id = ?").run(role, Number(id)); },
  setEmail(id, email) { db.prepare("UPDATE users SET email = ? WHERE id = ?").run(String(email).toLowerCase(), Number(id)); },
  remove(id) { db.prepare("DELETE FROM users WHERE id = ?").run(Number(id)); },
};

export const sessions = {
  create(token, userId, device, ip) {
    const t = now();
    db.prepare("INSERT INTO sessions(token, user_id, device, ip, created_at, last_seen) VALUES(?, ?, ?, ?, ?, ?)")
      .run(token, userId, device || "", ip || "", t, t);
  },
  get(token) { return db.prepare("SELECT * FROM sessions WHERE token = ?").get(token); },
  touch(token) { db.prepare("UPDATE sessions SET last_seen = ? WHERE token = ?").run(now(), token); },
  remove(token) { db.prepare("DELETE FROM sessions WHERE token = ?").run(token); },
  removeUser(userId) { db.prepare("DELETE FROM sessions WHERE user_id = ?").run(Number(userId)); },
  all() { return db.prepare("SELECT * FROM sessions ORDER BY last_seen DESC").all(); },
  forUser(userId) { return db.prepare("SELECT * FROM sessions WHERE user_id = ? ORDER BY last_seen DESC").all(Number(userId)); },
};

export { now };
