// Ponto de entrada: confere a versão do Node antes de carregar o servidor
// (o banco usa o SQLite embutido, disponível a partir do Node.js 22.13).
const [major, minor] = process.versions.node.split(".").map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`❌ Node.js ${process.versions.node} é antigo demais para o My Music.`);
  console.error("   Instale o Node.js 22 (LTS) ou mais novo: https://nodejs.org  —  ou rode: sudo bash deploy/instalar.sh");
  process.exit(1);
}
await import("./server.js");
