// Integração com a API do Mercado Pago (Pix, cartão, boleto) — sem dependências externas.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import { kvGet, kvSet, kvDel, now } from "./db.js";
import { HttpError } from "./http.js";

const API = process.env.MP_API_BASE || "https://api.mercadopago.com";
const KEY = "mp:config";

// ---------- criptografia das credenciais (AES-256-GCM) ----------
function secretKey() {
  if (process.env.APP_SECRET) return crypto.createHash("sha256").update(process.env.APP_SECRET).digest();
  const file = path.join(config.dataDir, "secret.key");
  if (!fs.existsSync(file)) fs.writeFileSync(file, crypto.randomBytes(32).toString("hex"), { mode: 0o600 });
  return Buffer.from(fs.readFileSync(file, "utf8").trim(), "hex");
}
export function encrypt(text) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", secretKey(), iv);
  const enc = Buffer.concat([c.update(String(text), "utf8"), c.final()]);
  return [iv.toString("base64"), c.getAuthTag().toString("base64"), enc.toString("base64")].join(".");
}
export function decrypt(blob) {
  if (!blob) return null;
  try {
    const [iv, tag, enc] = blob.split(".").map((x) => Buffer.from(x, "base64"));
    const d = crypto.createDecipheriv("aes-256-gcm", secretKey(), iv);
    d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString("utf8");
  } catch { return null; }
}

// ---------- configuração salva ----------
export const mpConfig = () => kvGet(KEY, null);
export const mpToken = () => decrypt(mpConfig()?.accessTokenEnc);
export const mpWebhookSecret = () => decrypt(mpConfig()?.webhookSecretEnc);

export function mpPublicView() {
  const c = mpConfig();
  if (!c || !c.accessTokenEnc) return { configured: false, status: "disconnected", mode: "test", publicKey: "" };
  const token = mpToken() || "";
  const hint = token ? `${token.slice(0, 8)}…${token.slice(-4)}` : "—";
  let warning = null;
  if (c.mode === "production" && token.startsWith("TEST-")) warning = "O Access Token salvo é de teste, mas o modo está em Produção.";
  if (!c.publicKey) warning = warning || "Falta a Public Key: os planos pagos com cartão ficam indisponíveis.";
  return { configured: true, mode: c.mode, status: c.status || "error", account: c.account || null, checkedAt: c.checkedAt || null,
    lastError: c.lastError || null, accessTokenHint: hint, publicKey: c.publicKey || "", hasWebhookSecret: !!c.webhookSecretEnc, warning };
}

export function mpSave(partial) {
  const cur = mpConfig() || {};
  const next = { ...cur, ...partial, updatedAt: now() };
  kvSet(KEY, next);
  return next;
}
export function mpDisconnect() { kvDel(KEY); }

export const mpReady = () => {
  const c = mpConfig();
  return !!(c && c.accessTokenEnc && c.status === "connected");
};

// ---------- chamadas HTTP ----------
async function call(method, url, body, { token = mpToken(), idempotency } = {}) {
  if (!token) throw new HttpError(400, "O Mercado Pago não está configurado. Peça ao administrador para salvar as credenciais.");
  let res;
  try {
    res = await fetch(API + url, {
      method,
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
        ...(idempotency ? { "X-Idempotency-Key": idempotency } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(25000),
    });
  } catch {
    throw new HttpError(502, "Não foi possível falar com o Mercado Pago agora. Tente novamente em instantes.");
  }
  const text = await res.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch {}
  if (!res.ok) {
    const cause = Array.isArray(data.cause) && data.cause[0]?.description;
    const msg = cause || data.message || `Erro ${res.status} no Mercado Pago.`;
    const err = new HttpError(res.status >= 500 ? 502 : 400, `Mercado Pago: ${msg}`);
    err.mpStatus = res.status;
    throw err;
  }
  return data;
}

const CURRENCY = { MLB: "BRL", MLA: "ARS", MLM: "MXN", MLC: "CLP", MCO: "COP", MPE: "PEN", MLU: "UYU" };

/** Testa as credenciais e devolve os dados da conta. */
export async function mpCheck(token) {
  try {
    const me = await call("GET", "/users/me", null, { token });
    const account = { id: me.id, nickname: me.nickname || me.email || String(me.id), siteId: me.site_id, currency: CURRENCY[me.site_id] || "BRL" };
    return { status: "connected", account, lastError: null, checkedAt: now() };
  } catch (e) {
    return { status: "error", lastError: e.mpStatus === 401 ? "Access Token inválido ou revogado." : e.message, checkedAt: now() };
  }
}

/** Formas de pagamento habilitadas na conta. */
export async function mpAccountMethods() {
  try {
    const list = await call("GET", "/v1/payment_methods");
    return new Set(list.filter((m) => m.status === "active").map((m) => m.payment_type_id).concat(list.some((m) => m.id === "pix") ? ["pix"] : []));
  } catch { return null; }
}

const pad = (n) => String(n).padStart(2, "0");
/** Data no formato aceito pelo Mercado Pago, no fuso de Brasília. */
export function mpDate(date) {
  const d = new Date(date.getTime() - 3 * 3600e3);
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}T${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}.000-03:00`;
}

export function notificationUrl(req) {
  const base = config.publicUrl || `${req.headers["x-forwarded-proto"] || "http"}://${req.headers.host}`;
  return base.startsWith("https://") ? `${base}/api/payments/webhook` : undefined;
}

export async function mpCreatePix({ amountCents, description, email, name, externalReference, req, minutes = 30 }) {
  const [first, ...rest] = String(name || "Cliente").trim().split(/\s+/);
  const body = {
    transaction_amount: Math.round(amountCents) / 100,
    description: String(description).slice(0, 200),
    payment_method_id: "pix",
    external_reference: externalReference,
    date_of_expiration: mpDate(new Date(Date.now() + minutes * 60e3)),
    payer: { email, first_name: first || "Cliente", last_name: rest.join(" ") || undefined },
  };
  const url = notificationUrl(req);
  if (url) body.notification_url = url;
  return call("POST", "/v1/payments", body, { idempotency: crypto.randomUUID() });
}

export async function mpCreateFromBrick({ formData, amountCents, description, email, externalReference, req }) {
  const body = {
    ...formData,
    transaction_amount: Math.round(amountCents) / 100,
    description: String(description).slice(0, 200),
    external_reference: externalReference,
    payer: { ...(formData?.payer || {}), email: formData?.payer?.email || email },
  };
  const url = notificationUrl(req);
  if (url) body.notification_url = url;
  return call("POST", "/v1/payments", body, { idempotency: crypto.randomUUID() });
}

export const mpGetPayment = (id) => call("GET", `/v1/payments/${encodeURIComponent(id)}`);
export const mpCancelPayment = (id) => call("PUT", `/v1/payments/${encodeURIComponent(id)}`, { status: "cancelled" });

/** Extrai os dados de pagamento (QR Code do Pix, boleto) da resposta do Mercado Pago. */
export function checkoutDataOf(p) {
  const t = p?.point_of_interaction?.transaction_data;
  if (p?.payment_method_id === "pix" && t?.qr_code) {
    return { kind: "pix", qrCode: t.qr_code, qrCodeBase64: t.qr_code_base64 || null, ticketUrl: t.ticket_url || null, expiresAt: p.date_of_expiration || null };
  }
  if (p?.payment_type_id === "ticket") {
    return { kind: "boleto", url: p.transaction_details?.external_resource_url || null, barcode: p.barcode?.content || null,
      digitableLine: p.transaction_details?.digitable_line || null, expiresAt: p.date_of_expiration || null };
  }
  return null;
}

/** Valida a assinatura secreta das notificações (cabeçalho x-signature). */
export function verifyWebhook(req, dataId) {
  const secret = mpWebhookSecret();
  if (!secret) return true;
  const sig = String(req.headers["x-signature"] || "");
  const parts = Object.fromEntries(sig.split(",").map((p) => p.trim().split("=")));
  if (!parts.ts || !parts.v1) return false;
  const reqId = req.headers["x-request-id"] || "";
  const manifest = `id:${String(dataId).toLowerCase()};request-id:${reqId};ts:${parts.ts};`;
  const hmac = crypto.createHmac("sha256", secret).update(manifest).digest("hex");
  try { return crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(parts.v1)); } catch { return false; }
}
