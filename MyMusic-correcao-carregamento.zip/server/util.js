import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { config } from "./config.js";
import { docs } from "./db.js";

export const uuid = () => crypto.randomUUID();
export const randKey = (n = 16) => crypto.randomBytes(n).toString("hex");
export const slug = (n = 10) => {
  const abc = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789";
  return Array.from(crypto.randomBytes(n), (b) => abc[b % abc.length]).join("");
};

export const dirs = {
  audio: path.join(config.dataDir, "audio"),
  covers: path.join(config.dataDir, "covers"),
  uploads: path.join(config.dataDir, "uploads"),
  files: path.join(config.dataDir, "files"),
};
for (const d of Object.values(dirs)) fs.mkdirSync(d, { recursive: true });

export const coverUrl = (key) => (key ? `/api/covers/${key}` : null);

export function saveCover(buffer, contentType = "image/jpeg") {
  const key = randKey(16);
  fs.writeFileSync(path.join(dirs.covers, key), buffer);
  fs.writeFileSync(path.join(dirs.covers, key + ".type"), contentType);
  return key;
}

export function saveFile(buffer, contentType = "application/octet-stream", name = "") {
  const key = randKey(16);
  fs.writeFileSync(path.join(dirs.files, key), buffer);
  fs.writeFileSync(path.join(dirs.files, key + ".json"), JSON.stringify({ contentType, name, size: buffer.length }));
  return { key, url: `/api/files/${key}`, size: buffer.length, contentType, name };
}

const statKey = (uid, sid) => `${uid}:${sid}`;
export function songStats(uid, sid) {
  return docs.get("songstat", statKey(uid, sid)) || { favorite: false, playCount: 0, lastPlayedAt: null };
}
export function setSongStats(uid, sid, partial) {
  const cur = songStats(uid, sid);
  return docs.put("songstat", statKey(uid, sid), { ...cur, ...partial, userId: uid, songId: sid }, uid);
}

/** Converte um documento interno de música no formato que o app usa. */
export function songOut(song, uid) {
  if (!song) return null;
  const st = uid ? songStats(uid, song.id) : { favorite: false, playCount: 0, lastPlayedAt: null };
  const chunkSize = config.chunkSize;
  return {
    id: song.id,
    title: song.title || "Sem título",
    artist: song.artist || "",
    album: song.album || "",
    genre: song.genre || "",
    year: song.year ?? null,
    duration: Number(song.duration) || 0,
    mimeType: song.mimeType || "audio/mpeg",
    size: Number(song.size) || 0,
    coverKey: song.coverKey || null,
    coverUrl: coverUrl(song.coverKey),
    contentHash: song.contentHash || null,
    status: song.status || "ready",
    published: song.status === "ready",
    audioVersion: song.audioVersion ?? 0,
    categoryIds: song.categoryIds || [],
    favorite: !!st.favorite,
    playCount: st.playCount || 0,
    lastPlayedAt: st.lastPlayedAt || null,
    createdAt: song.createdAt,
    updatedAt: song.updatedAt || song.createdAt,
    uploadedBy: song.ownerId ?? null,
    chunkSize,
    chunkCount: Math.max(1, Math.ceil((Number(song.size) || 0) / chunkSize)),
  };
}

export function audioPath(id) { return path.join(dirs.audio, id); }

export function userAgentDevice(ua = "") {
  if (/iphone|ipad/i.test(ua)) return "iPhone/iPad";
  if (/android/i.test(ua)) return "Android";
  if (/windows/i.test(ua)) return "Windows";
  if (/mac os/i.test(ua)) return "Mac";
  if (/linux/i.test(ua)) return "Linux";
  return "Navegador";
}
