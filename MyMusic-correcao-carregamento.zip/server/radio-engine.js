// Motor da Rádio ao Vivo: monta a transmissão HLS (trechos de MP3) direto das músicas da biblioteca
// ou recebe os trechos enviados pelo estúdio (microfone no navegador do administrador).
import fs from "node:fs";
import crypto from "node:crypto";
import { audioPath } from "./util.js";
import { docs } from "./db.js";

const SEG_SECONDS = 4;          // duração alvo de cada trecho
const WINDOW = 6;               // trechos visíveis na playlist ao vivo
const LOOKAHEAD_MS = 6000;      // quantos ms à frente o servidor prepara

// ----------------------------------------------------------------- leitura de MP3
const BR1 = [0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0];
const BR2 = [0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0];
const SR = { 3: [44100, 48000, 32000], 2: [22050, 24000, 16000], 0: [11025, 12000, 8000] };

function frameAt(buf, i) {
  if (i + 4 > buf.length || buf[i] !== 0xff || (buf[i + 1] & 0xe0) !== 0xe0) return null;
  const ver = (buf[i + 1] >> 3) & 3, layer = (buf[i + 1] >> 1) & 3;
  if (ver === 1 || layer !== 1) return null; // só MPEG Layer III
  const brIdx = buf[i + 2] >> 4, srIdx = (buf[i + 2] >> 2) & 3, pad = (buf[i + 2] >> 1) & 1;
  if (brIdx === 0 || brIdx === 15 || srIdx === 3) return null;
  const br = (ver === 3 ? BR1 : BR2)[brIdx] * 1000;
  const sr = SR[ver][srIdx];
  const samples = ver === 3 ? 1152 : 576;
  const len = Math.floor(((ver === 3 ? 144 : 72) * br) / sr) + pad;
  return len > 4 ? { len, sr, samples } : null;
}

const cache = new Map();
/** Divide uma música MP3 em trechos de ~4s (por quadros, sem recodificar). */
export function songSegments(song) {
  const key = `${song.id}:${song.audioVersion || 0}:${song.size}`;
  if (cache.has(key)) return cache.get(key);
  const file = audioPath(song.id);
  if (!fs.existsSync(file)) return null;
  const buf = fs.readFileSync(file);
  let i = 0;
  if (buf.slice(0, 3).toString() === "ID3") {
    i = 10 + ((buf[6] << 21) | (buf[7] << 14) | (buf[8] << 7) | buf[9]) + ((buf[5] & 0x10) ? 10 : 0);
  }
  // procura o primeiro quadro válido seguido de outro válido
  while (i < buf.length - 4) {
    const f = frameAt(buf, i);
    if (f && frameAt(buf, i + f.len)) break;
    i++;
  }
  // pula o quadro de informação (Xing/Info/VBRI), que declara a duração total do arquivo
  const f0 = frameAt(buf, i);
  if (f0) {
    const head = buf.slice(i, i + Math.min(f0.len, 64)).toString("latin1");
    if (/Xing|Info|VBRI/.test(head)) i += f0.len;
  }
  const segs = [];
  let segStart = i, segSamples = 0, sr = 0, total = 0;
  while (i < buf.length) {
    const f = frameAt(buf, i);
    if (!f) break;
    if (!sr) sr = f.sr;
    if (f.sr !== sr) break;
    segSamples += f.samples;
    i += f.len;
    if (segSamples / sr >= SEG_SECONDS) {
      segs.push({ off: segStart, len: i - segStart, dur: segSamples / sr });
      total += segSamples / sr;
      segStart = i; segSamples = 0;
    }
  }
  if (segSamples && i > segStart) { segs.push({ off: segStart, len: i - segStart, dur: segSamples / sr }); total += segSamples / sr; }
  const out = segs.length ? { segs, duration: total, sr } : null;
  cache.set(key, out);
  if (cache.size > 400) cache.delete(cache.keys().next().value);
  return out;
}

/** Cabeçalho ID3 com o carimbo de tempo exigido pelo HLS para áudio MP3 puro. */
function id3Timestamp(pts) {
  const owner = Buffer.from("com.apple.streaming.transportStreamTimestamp\0", "latin1");
  const ts = Buffer.alloc(8);
  const v = Math.floor(pts) % 2 ** 33;
  ts.writeUInt32BE(Math.floor(v / 2 ** 32), 0);
  ts.writeUInt32BE(v % 2 ** 32, 4);
  const frameData = Buffer.concat([owner, ts]);
  const frame = Buffer.concat([Buffer.from("PRIV"), Buffer.from([0, 0, 0, frameData.length, 0, 0]), frameData]);
  const size = frame.length;
  const header = Buffer.from([0x49, 0x44, 0x33, 4, 0, 0, (size >> 21) & 0x7f, (size >> 14) & 0x7f, (size >> 7) & 0x7f, size & 0x7f]);
  return Buffer.concat([header, frame]);
}

// ----------------------------------------------------------------- estações
export const stations = new Map(); // id -> station
const ended = new Map();           // id -> station encerrada (serve os últimos trechos por um tempo)
const listeners = new Map();       // sessionId -> Map(viewerKey -> timestamp)

export function touchListener(sessionId, key) {
  if (!listeners.has(sessionId)) listeners.set(sessionId, new Map());
  listeners.get(sessionId).set(String(key), Date.now());
}
export function listenerCount(sessionId) {
  const m = listeners.get(sessionId);
  if (!m) return 0;
  const limit = Date.now() - 45_000;
  for (const [k, t] of m) if (t < limit) m.delete(k);
  return m.size;
}

const songDoc = (id) => docs.get("songs", id);
const shuffleArr = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [r[i], r[j]] = [r[j], r[i]]; } return r; };

/** Só músicas MP3 prontas podem ir para a rádio automática. */
export function playableIds(ids) {
  return ids.filter((id) => { const s = songDoc(id); return s && s.status === "ready" && /mpeg|mp3/i.test(s.mimeType || "") && songSegments(s); });
}

export function createAutoStation(opts) {
  const id = crypto.randomUUID();
  const order = playableIds(opts.trackIds);
  if (!order.length) return null;
  const st = {
    id, mode: "auto", key: opts.key, program: opts.program, description: opts.description || "", coverKey: opts.coverKey || null,
    programId: opts.programId || null, playlistId: opts.playlistId || null, runId: opts.runId || null,
    startedAt: new Date().toISOString(), endsAt: opts.endsAt || null, endMode: opts.endMode || "finish_song",
    repeat: opts.repeat !== false, shuffle: !!opts.shuffle, paused: false, pausedAt: null, stopAt: null,
    requestsEnabled: opts.requestsEnabled !== false, manual: !!opts.manual,
    baseIds: opts.trackIds, queue: opts.shuffle ? shuffleArr(order) : order, history: [],
    cursor: null, segs: [], seq: 0, discSeq: 0, t0: Date.now(), state: "live", stopAfterSong: false, onEnd: opts.onEnd || null,
  };
  stations.set(id, st);
  ensure(st);
  return st;
}

export function createStudioStation({ program, coverKey, onEnd }) {
  const id = crypto.randomUUID();
  const st = { id, mode: "studio", key: "studio", program, coverKey, startedAt: new Date().toISOString(), segs: [], seq: 0, discSeq: 0,
    state: "starting", lastAudioAt: Date.now(), nowPlaying: null, onEnd };
  stations.set(id, st);
  return st;
}

function nextSong(st) {
  if (st.stopAfterSong) return null;
  if (!st.queue.length) {
    if (!st.repeat) return null;
    const ids = playableIds(st.baseIds);
    if (!ids.length) return null;
    st.queue = st.shuffle ? shuffleArr(ids) : ids;
  }
  return st.queue.shift();
}

function lastSeg(st) { return st.segs[st.segs.length - 1]; }

/** Prepara os próximos trechos da estação automática conforme o relógio. */
export function ensure(st) {
  if (st.mode !== "auto" || st.state === "ended" || st.paused) return;
  const now = Date.now();
  if (st.endsAt && st.endMode === "immediate" && now >= new Date(st.endsAt).getTime()) return endStation(st, "schedule");
  if (st.endsAt && now >= new Date(st.endsAt).getTime()) st.stopAfterSong = true;
  let guard = 0;
  while (guard++ < 50) {
    const last = lastSeg(st);
    const nextStart = last ? last.start + last.dur * 1000 : now;
    if (nextStart > now + LOOKAHEAD_MS) break;
    if (!st.cursor) {
      const sid = nextSong(st);
      if (!sid) {
        if (!last || nextStart <= now) return endStation(st, st.stopAfterSong ? "schedule" : "queue_end");
        break;
      }
      const song = songDoc(sid);
      const parsed = song && songSegments(song);
      if (!parsed) continue;
      st.cursor = { songId: sid, idx: 0, songStart: nextStart };
      st.history.push(sid);
      if (st.history.length > 200) st.history.shift();
    }
    const song = songDoc(st.cursor.songId);
    const parsed = song && songSegments(song);
    if (!parsed || st.cursor.idx >= parsed.segs.length) { st.cursor = null; continue; }
    const seg = parsed.segs[st.cursor.idx];
    const disc = st.cursor.idx === 0 && !!last || !!st.forceDisc;
    st.forceDisc = false;
    if (st.cursor.idx === 0) st.cursor.songStart = nextStart;
    st.segs.push({ seq: st.seq++, start: nextStart, dur: seg.dur, songId: song.id, off: seg.off, len: seg.len, disc,
      pts: Math.round((nextStart - st.t0) * 90) + 90000 });
    st.cursor.idx++;
    if (st.cursor.idx >= parsed.segs.length) st.cursor = null;
  }
  trim(st);
}

function trim(st) {
  const now = Date.now();
  while (st.segs.length > 40 && st.segs[0].start + st.segs[0].dur * 1000 < now - 60_000) {
    const s = st.segs.shift();
    if (s.disc) st.discSeq++;
  }
}

/** Trechos já publicados (o que os ouvintes podem baixar). */
function published(st) {
  const now = Date.now();
  return st.mode === "studio" ? st.segs : st.segs.filter((s) => s.start <= now);
}

export function playlistFor(id) {
  const st = stations.get(id) || ended.get(id);
  if (!st) return null;
  if (st.mode === "auto") ensure(st);
  const pub = published(st);
  const win = pub.slice(-WINDOW);
  if (!win.length) {
    return "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:5\n#EXT-X-MEDIA-SEQUENCE:0\n" + (st.state === "ended" ? "#EXT-X-ENDLIST\n" : "");
  }
  const target = Math.max(5, Math.ceil(Math.max(...win.map((s) => s.dur))));
  const firstIdx = st.segs.indexOf(win[0]);
  const disc = st.discSeq + st.segs.slice(0, firstIdx).filter((s) => s.disc).length;
  const lines = ["#EXTM3U", "#EXT-X-VERSION:3", `#EXT-X-TARGETDURATION:${target}`, `#EXT-X-MEDIA-SEQUENCE:${win[0].seq}`,
    `#EXT-X-DISCONTINUITY-SEQUENCE:${disc}`];
  win.forEach((s) => {
    if (s.disc) lines.push("#EXT-X-DISCONTINUITY");
    lines.push(`#EXTINF:${s.dur.toFixed(3)},`, `seg-${s.seq}.mp3`);
  });
  if (st.state === "ended") lines.push("#EXT-X-ENDLIST");
  return lines.join("\n") + "\n";
}

export function segmentFor(id, seq) {
  const st = stations.get(id) || ended.get(id);
  if (!st) return null;
  const s = st.segs.find((x) => x.seq === seq);
  if (!s) return null;
  if (st.mode === "studio") return s.data;
  const fd = fs.openSync(audioPath(s.songId), "r");
  const body = Buffer.alloc(s.len);
  fs.readSync(fd, body, 0, s.len, s.off);
  fs.closeSync(fd);
  return Buffer.concat([id3Timestamp(s.pts), body]);
}

/** Estúdio: recebe um trecho de áudio já codificado no navegador. */
export function pushStudioSegment(st, seq, data, durationMs, disc) {
  st.segs.push({ seq, start: Date.now(), dur: Math.max(0.1, durationMs / 1000), data, disc: !!disc && st.segs.length > 0 });
  st.state = "live";
  st.lastAudioAt = Date.now();
  while (st.segs.length > 30) { const s = st.segs.shift(); if (s.disc) st.discSeq++; }
}

/** Situação atual da estação automática: música tocando, posição e próximas. */
export function nowPlaying(st) {
  if (st.mode === "studio") return st.nowPlaying ? { songId: st.nowPlaying, positionMs: 0 } : null;
  const now = st.paused ? st.pausedAt : Date.now();
  const pub = st.segs.filter((s) => s.start <= now);
  const cur = pub[pub.length - 1];
  if (!cur) return null;
  let first = cur;
  for (let i = st.segs.indexOf(cur); i >= 0 && st.segs[i].songId === cur.songId; i--) { first = st.segs[i]; if (st.segs[i].disc) break; }
  return { songId: cur.songId, positionMs: Math.max(0, now - first.start) };
}

export function upNext(st, limit = 20) {
  if (st.mode !== "auto") return [];
  const np = nowPlaying(st);
  const ids = [];
  const future = st.segs.filter((s) => s.start > Date.now());
  for (const s of future) if (s.songId !== np?.songId && !ids.includes(s.songId)) ids.push(s.songId);
  if (st.cursor && st.cursor.songId !== np?.songId && !ids.includes(st.cursor.songId)) ids.push(st.cursor.songId);
  return [...ids, ...st.queue].slice(0, limit);
}

/** Remove o que ainda não foi ao ar (para trocar de música/playlist). */
function dropFuture(st) {
  const now = Date.now();
  st.segs = st.segs.filter((s) => s.start <= now);
  st.cursor = null;
  st.forceDisc = true;
}

export function skip(st) {
  dropFuture(st);
  ensure(st);
}
export function previous(st) {
  const np = nowPlaying(st);
  const hist = st.history.filter((x) => x !== np?.songId);
  const prev = hist[hist.length - 1];
  dropFuture(st);
  if (np) st.queue.unshift(np.songId);
  if (prev) st.queue.unshift(prev);
  ensure(st);
}
export function playNow(st, songId) {
  dropFuture(st);
  st.queue = [songId, ...st.queue.filter((x) => x !== songId)];
  ensure(st);
}
export function setQueue(st, ids) {
  st.queue = playableIds(ids);
  const now = Date.now();
  const np = nowPlaying(st);
  // mantém o que está tocando e refaz o que vem depois
  st.segs = st.segs.filter((s) => s.start <= now || s.songId === np?.songId);
  if (st.cursor && st.cursor.songId !== np?.songId) st.cursor = null;
  ensure(st);
}
export function switchTracks(st, trackIds, when, meta = {}) {
  st.baseIds = trackIds;
  Object.assign(st, meta);
  const ids = playableIds(trackIds);
  st.queue = st.shuffle ? shuffleArr(ids) : ids;
  if (when === "now") dropFuture(st);
  else {
    const np = nowPlaying(st);
    st.segs = st.segs.filter((s) => s.start <= Date.now() || s.songId === np?.songId);
  }
  ensure(st);
}
export function pause(st) {
  if (st.paused) return;
  dropFuture(st);
  const np = nowPlaying(st);
  st.paused = true;
  st.pausedAt = Date.now();
  st.state = "paused";
  if (np) {
    // retoma a mesma música de onde parou (no trecho seguinte)
    const song = songDoc(np.songId);
    const parsed = song && songSegments(song);
    const lastPlayed = st.segs.filter((s) => s.songId === np.songId).length;
    st.resumeCursor = parsed ? { songId: np.songId, idx: Math.min(lastPlayed, parsed.segs.length) } : null;
  }
}
export function resume(st) {
  if (!st.paused) return;
  st.paused = false;
  st.state = "live";
  st.forceDisc = true;
  const gap = Date.now() - st.pausedAt;
  st.t0 += 0; // carimbos continuam crescendo com o relógio
  if (st.resumeCursor) st.cursor = { ...st.resumeCursor, songStart: Date.now() };
  st.resumeCursor = null;
  st.pausedAt = null;
  ensure(st);
  return gap;
}

export function endStation(st, reason = "admin") {
  if (st.state === "ended") return;
  st.state = "ended";
  st.endedAt = new Date().toISOString();
  st.endReason = reason;
  stations.delete(st.id);
  ended.set(st.id, st);
  setTimeout(() => { ended.delete(st.id); listeners.delete(st.id); }, 120_000).unref();
  try { st.onEnd?.(st, reason); } catch (e) { console.error("[rádio] erro ao encerrar", e); }
}

// relógio: mantém as estações automáticas avançando e detecta estúdio sem áudio
setInterval(() => {
  for (const st of [...stations.values()]) {
    if (st.mode === "auto") ensure(st);
    else if (st.state !== "ended" && Date.now() - st.lastAudioAt > 90_000) endStation(st, "timeout");
    else if (st.state === "live" && Date.now() - st.lastAudioAt > 12_000) st.state = "interrupted";
  }
}, 1000).unref();
