import { kvGet, kvSet, kvDel, now, users, docs } from "../db.js";
import { fail } from "../http.js";
import { requireUser, requireAdmin } from "../auth.js";
import { coverUrl } from "../util.js";
import { radioHomeInfo } from "./radio.js";

const DEFAULT_COLORS = { primary: "#2f7dff", secondary: "#1452e0", highlight: "#5aa0ff", button: "#2f7dff", text: "#eef1f7",
  background: "#07080b", card: "#11141b", border: "#232937", icon: "#8a93a6" };

function brandingOut() {
  const b = kvGet("branding", { logo: null, icon: null, version: 0 });
  return {
    logo: b.logo ? { ...b.logo, url: coverUrl(b.logo.key) } : null,
    icon: b.icon ? { ...b.icon, url192: coverUrl(b.icon.key192), url512: coverUrl(b.icon.key512) } : null,
    version: b.version || 0,
  };
}

export function registerExtras(r) {
  // -------- Logo e ícone do app --------
  r.get("/api/branding", () => brandingOut());
  r.put("/api/branding", async (ctx) => {
    requireAdmin(ctx);
    const body = await ctx.json();
    const cur = kvGet("branding", { logo: null, icon: null, version: 0 });
    const next = { ...cur, version: (cur.version || 0) + 1 };
    if ("logo" in body) next.logo = body.logo ? { key: body.logo.key, width: Number(body.logo.width), height: Number(body.logo.height) } : null;
    if ("icon" in body) next.icon = body.icon ? { source: body.icon.source === "logo" ? "logo" : "custom", key192: body.icon.key192, key512: body.icon.key512 } : null;
    kvSet("branding", next);
    return brandingOut();
  });
  r.get("/api/branding/icon/:size", (ctx) => {
    const b = kvGet("branding", {});
    const key = ctx.params.size === "512" ? b.icon?.key512 : b.icon?.key192;
    ctx.res.writeHead(302, { Location: key ? coverUrl(key) : ctx.params.size === "512" ? "/icon-512.png" : "/icon-192.png" });
    ctx.res.end();
    return ctx.HANDLED;
  });

  // -------- Cores do tema --------
  r.get("/api/appearance", () => ({ colors: kvGet("appearance", null) || DEFAULT_COLORS, custom: !!kvGet("appearance", null) }));
  r.put("/api/appearance", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const colors = {};
    for (const k of Object.keys(DEFAULT_COLORS)) {
      const v = b.colors?.[k];
      if (typeof v !== "string" || !/^#[0-9a-f]{6}$/i.test(v)) fail(400, "Cor inválida.");
      colors[k] = v.toLowerCase();
    }
    kvSet("appearance", colors);
    return { colors, custom: true };
  });
  r.delete("/api/appearance", (ctx) => { requireAdmin(ctx); kvDel("appearance"); return { colors: DEFAULT_COLORS, custom: false }; });

  // -------- Tela inicial (biblioteca ou rádio) --------
  const homeSettings = () => ({ start: "library", swipe: false, ...kvGet("home-screen", {}) });
  r.get("/api/home-screen", (ctx) => { requireUser(ctx); return homeSettings(); });
  r.get("/api/admin/home-screen", (ctx) => { requireAdmin(ctx); return { settings: homeSettings(), radio: radioHomeInfo() }; });
  r.put("/api/admin/home-screen", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    kvSet("home-screen", { start: b.start === "radio" ? "radio" : "library", swipe: !!b.swipe });
    return { settings: homeSettings(), radio: radioHomeInfo() };
  });


  // -------- Controle de acesso (aprovação de cadastros) --------
  const accessOut = () => {
    const st = kvGet("setting:/api/admin/access", {});
    return { settings: { required: !!st.requireApproval }, pending: users.all().filter((u) => u.role === "user" && u.access === "pending").length };
  };
  r.get("/api/admin/access", (ctx) => { requireAdmin(ctx); return accessOut(); });
  r.put("/api/admin/access", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    kvSet("setting:/api/admin/access", { ...kvGet("setting:/api/admin/access", {}), requireApproval: !!b.required });
    return accessOut();
  });

  // -------- Respostas neutras para recursos opcionais (o app os esconde) --------
  r.get("/api/home-ads", (ctx) => { requireUser(ctx); return { enabled: false, rotateSeconds: 8, ads: [], items: [] }; });
  r.get("/api/received/summary", (ctx) => { requireUser(ctx); return { pending: 0, unseen: 0 }; });
  r.get("/api/upload-drafts", (ctx) => { requireUser(ctx); return docs.list("upload-drafts", ctx.user.id); });
  r.put("/api/upload-drafts/:id", async (ctx) => { const u = requireUser(ctx); return docs.put("upload-drafts", ctx.params.id, await ctx.json(), u.id); });
  r.delete("/api/upload-drafts/:id", (ctx) => { requireUser(ctx); docs.del("upload-drafts", ctx.params.id); return { ok: true }; });
  r.get("/api/push", (ctx) => { requireUser(ctx); return { available: false, publicKey: null, preference: { enabled: false } }; });
  r.get("/api/backup/jobs/active", (ctx) => { requireUser(ctx); return { job: null }; });
  r.get("/api/admin/alerts/summary", (ctx) => { requireAdmin(ctx); return { unread: 0, latest: null }; });
  r.get("/api/admin/alerts", (ctx) => { requireAdmin(ctx); return { alerts: [], items: [], unread: 0 }; });
  r.get("/api/referral/me", (ctx) => { requireUser(ctx); return { available: false, enabled: false, card: null }; });
  r.get("/api/exclusive/me", (ctx) => { requireUser(ctx); return { active: false, membership: null }; });

  // -------- Recursos desativados nesta instalação (respondem de forma que o app os esconda) --------
  const off = { available: false, enabled: false, reason: "disabled", message: "Recurso desativado nesta instalação." };
}
