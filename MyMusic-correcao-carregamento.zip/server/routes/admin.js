import { users, sessions, docs, kvGet, kvSet, now } from "../db.js";
import { config } from "../config.js";
import { fail } from "../http.js";
import { hashPassword, publicUser, requireUser, requireAdmin } from "../auth.js";
import { uuid, randKey, slug, coverUrl, songOut, userAgentDevice, saveFile } from "../util.js";
import { emailView, emailSave, testEmailKey } from "../email.js";

const SONGS = "songs";

function adminUserOut(u) {
  const s = sessions.forUser(u.id);
  return {
    ...publicUser(u),
    status: u.blocked ? "blocked" : "active",
    lastLoginAt: u._data.lastLoginAt || null,
    lastSeenAt: s[0]?.last_seen || null,
    sessionCount: s.length,
    plan: null, subscription: null,
    playCount: docs.list("plays", u.id).length,
  };
}

export function registerAdmin(r) {
  // ---------------- Usuários ----------------
  r.get("/api/admin/users", (ctx) => { requireAdmin(ctx); return users.all().map(adminUserOut); });

  r.patch("/api/admin/users/:id", async (ctx) => {
    const admin = requireAdmin(ctx);
    const b = await ctx.json();
    const u = users.byId(ctx.params.id);
    if (!u) fail(404, "Usuário não encontrado.");
    const partial = {};
    if (typeof b.displayName === "string") partial.displayName = b.displayName;
    if (typeof b.name === "string") partial.displayName = b.name;
    if (b.blocked !== undefined) { partial.blocked = !!b.blocked; if (b.blocked) sessions.removeUser(u.id); }
    if (b.status) { partial.blocked = b.status === "blocked"; if (partial.blocked) sessions.removeUser(u.id); }
    if (b.access) partial.access = b.access;
    if (b.role && u.id !== admin.id) users.setRole(u.id, b.role === "admin" ? "admin" : "user");
    if (b.password) {
      if (String(b.password).length < 8) fail(400, "A senha deve ter pelo menos 8 caracteres.");
      users.setPassword(u.id, hashPassword(b.password));
    }
    if (typeof b.email === "string" && b.email.toLowerCase() !== u.email) {
      if (users.byEmail(b.email)) fail(409, "Este e-mail já está em uso.");
      users.setEmail(u.id, b.email);
    }
    return adminUserOut(users.updateData(u.id, partial));
  });

  r.delete("/api/admin/users/:id", (ctx) => {
    const admin = requireAdmin(ctx);
    if (Number(ctx.params.id) === admin.id) fail(400, "Você não pode excluir a própria conta.");
    users.remove(ctx.params.id);
    return { ok: true };
  });

  r.put("/api/admin/users/:id/approval", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const access = b.access || b.status || (b.approved === false ? "rejected" : "approved");
    const u = users.updateData(ctx.params.id, { access, approvedNotice: access === "approved", reviewedAt: now(), note: b.note || b.reason || null });
    if (!u) fail(404, "Usuário não encontrado.");
    return adminUserOut(u);
  });

  r.post("/api/admin/users/:id/reset-link", (ctx) => {
    requireAdmin(ctx);
    const u = users.byId(ctx.params.id);
    if (!u) fail(404, "Usuário não encontrado.");
    const token = randKey(24);
    const expiresAt = new Date(Date.now() + 24 * 3600e3).toISOString();
    docs.put("resets", token, { userId: u.id, expiresAt });
    const base = config.publicUrl || `${ctx.req.headers["x-forwarded-proto"] || "http"}://${ctx.req.headers.host}`;
    return { url: `${base}/redefinir-senha?token=${token}`, link: `${base}/redefinir-senha?token=${token}`, expiresAt };
  });

  r.post("/api/admin/users/:id/signup-notice", (ctx) => { requireAdmin(ctx); return { ok: true }; });

  // ---------------- E-mail (Resend) ----------------
  r.get("/api/admin/email", (ctx) => { requireAdmin(ctx); return emailView(); });
  r.put("/api/admin/email", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    if (b.clear) return emailSave({ clear: true });
    const from = String(b.from || "").trim();
    if (!from || !/@/.test(from)) fail(400, "Informe o remetente, por exemplo: My Music <nao-responda@seudominio.com.br>.");
    const key = String(b.apiKey || "").trim();
    if (!key && !emailView().hasApiKey) fail(400, "Informe a chave de API do Resend.");
    if (key && !(await testEmailKey(key))) fail(400, "A chave de API do Resend foi recusada. Confira e tente de novo.");
    return emailSave({ from, apiKey: key || undefined });
  });

  // ---------------- Sessões ----------------
  const sessionOut = (s, current) => {
    const u = users.byId(s.user_id);
    return { id: s.token.slice(0, 16), userId: s.user_id, userName: u?.displayName, email: u?.email, name: u?.displayName,
      device: userAgentDevice(s.device), userAgent: s.device, ip: s.ip, createdAt: s.created_at, lastSeenAt: s.last_seen,
      current: s.token === current };
  };
  r.get("/api/admin/sessions", (ctx) => {
    requireAdmin(ctx);
    const settings = { singleDevice: false, ...kvGet("setting:/api/admin/sessions", {}) };
    return { ...settings, settings, sessions: sessions.all().map((s) => sessionOut(s, ctx.session?.token)) };
  });
  r.put("/api/admin/sessions", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const cur = kvGet("setting:/api/admin/sessions", {});
    const next = kvSet("setting:/api/admin/sessions", { ...cur, ...(b.settings || b) });
    kvSet("setting:/api/admin/access", { ...kvGet("setting:/api/admin/access", {}), singleDevice: !!next.singleDevice });
    return { ...next, settings: next, sessions: sessions.all().map((s) => sessionOut(s, ctx.session?.token)) };
  });
  r.delete("/api/admin/sessions/:id", (ctx) => {
    requireAdmin(ctx);
    for (const s of sessions.all()) if (s.token.startsWith(ctx.params.id) || String(s.user_id) === ctx.params.id) sessions.remove(s.token);
    return { ok: true };
  });

  // ---------------- Planos (sem cobrança obrigatória) ----------------
  const planOut = (p) => ({ active: true, billing: "free", priceCents: 0, features: {}, order: 0, ...p });
  r.get("/api/plans", (ctx) => { requireUser(ctx); return docs.list("plans").map(planOut).sort((a, b) => (a.order ?? 0) - (b.order ?? 0)); });
  r.post("/api/plans", async (ctx) => { requireAdmin(ctx); const b = await ctx.json(); return planOut(docs.put("plans", uuid(), { ...b, createdAt: now() })); });
  r.patch("/api/plans/:id", async (ctx) => {
    requireAdmin(ctx);
    const p = docs.patch("plans", ctx.params.id, await ctx.json());
    if (!p) fail(404, "Plano não encontrado.");
    return planOut(p);
  });
  r.delete("/api/plans/:id", (ctx) => { requireAdmin(ctx); docs.del("plans", ctx.params.id); return { ok: true }; });
  r.get("/api/plans/visibility", (ctx) => { requireUser(ctx); return { enabled: docs.list("plans").some((p) => p.active !== false), visible: docs.list("plans").some((p) => p.active !== false) }; });
  r.get("/api/plans/history", (ctx) => { requireUser(ctx); return []; });
  r.get("/api/plans/me", (ctx) => {
    const u = requireUser(ctx);
    const source = u.role === "admin" ? "admin" : "unrestricted";
    const entitlement = { source, plan: null, planId: null, planName: null, exclusive: null, expiresAt: null,
      limits: { maxSongs: null, maxStorageBytes: null }, features: {}, unlimited: true };
    return { entitlement, plan: null, subscription: null, usage: { songs: 0, storageBytes: 0 }, pendingPayment: null, history: [] };
  });

  // ---------------- Playlists dos usuários ----------------
  const UP = "user-playlists";
  const upSettings = () => ({ creation: true, sharing: false, requireApproval: true, ...kvGet("user-playlists:settings", {}) });
  const upState = (p, st) => {
    if (p.visibility !== "shared") return "private";
    if (!st.sharing) return "off";
    if (p.hidden) return "hidden";
    if (p.adminStatus === "rejected") return "rejected";
    if (p.adminStatus === "removed") return "removed";
    if (p.adminStatus === "pending") return "pending";
    return "shared";
  };
  const upOut = (p, uid) => {
    const st = upSettings();
    const songs = (p.songIds || []).filter((id) => { const s = docs.get(SONGS, id); return s && s.status === "ready"; });
    const owner = users.byId(p.ownerId);
    const first = songs.map((id) => docs.get(SONGS, id)).find((s) => s.coverKey);
    return { id: p.id, name: p.name, description: p.description || "", ownerId: p.ownerId, ownerName: owner?.displayName || "",
      visibility: p.visibility || "private", state: upState(p, st), adminStatus: p.adminStatus || (p.visibility === "shared" ? "approved" : "private"),
      hidden: !!p.hidden, adminNote: p.adminNote || null,
      coverKey: p.coverKey || null, customCoverUrl: coverUrl(p.coverKey), coverUrl: coverUrl(p.coverKey) || coverUrl(first?.coverKey),
      songIds: songs, songCount: songs.length, saveCount: (p.savedBy || []).length, playCount: p.plays || 0,
      saved: (p.savedBy || []).includes(uid), mine: p.ownerId === uid, history: p.history || [],
      createdAt: p.createdAt, updatedAt: p.updatedAt || p.createdAt };
  };
  const isCommunity = (p) => upState(p, upSettings()) === "shared";
  const statusFor = (visibility, prev) => {
    if (visibility !== "shared") return "private";
    const st = upSettings();
    return st.requireApproval || prev === "rejected" || prev === "removed" ? "pending" : "approved";
  };
  const logUp = (p, action, by) => [...(p.history || []), { action, by, at: now() }].slice(-50);

  r.get("/api/user-playlists", (ctx) => {
    const u = requireUser(ctx);
    const all = docs.list(UP);
    return { settings: upSettings(), canCreate: upSettings().creation !== false,
      mine: all.filter((p) => p.ownerId === u.id).map((p) => upOut(p, u.id)),
      saved: all.filter((p) => p.ownerId !== u.id && (p.savedBy || []).includes(u.id) && isCommunity(p)).map((p) => upOut(p, u.id)) };
  });
  r.get("/api/user-playlists/community", (ctx) => {
    const u = requireUser(ctx);
    return { enabled: !!upSettings().sharing, items: docs.list(UP).filter(isCommunity).map((p) => upOut(p, u.id)) };
  });
  r.post("/api/user-playlists", async (ctx) => {
    const u = requireUser(ctx);
    if (upSettings().creation === false && u.role !== "admin") fail(403, "A criação de playlists está desativada.");
    const b = await ctx.json();
    if (!String(b.name || "").trim()) fail(400, "Dê um nome à playlist.");
    const visibility = b.visibility === "shared" && upSettings().sharing ? "shared" : "private";
    const p = docs.put(UP, uuid(), { name: b.name.trim().slice(0, 80), description: b.description || "", visibility,
      adminStatus: statusFor(visibility), coverKey: b.coverKey || null, songIds: (b.songIds || []).slice(0, 500), ownerId: u.id,
      savedBy: [], history: [{ action: "create", by: "owner", at: now() }], createdAt: now() }, u.id);
    return { playlist: upOut(p, u.id) };
  });
  r.get("/api/user-playlists/:id", (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (!p || (p.ownerId !== u.id && !isCommunity(p) && u.role !== "admin")) fail(404, "Playlist não encontrada.");
    return { playlist: upOut(p, u.id) };
  });
  r.patch("/api/user-playlists/:id", async (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (!p || p.ownerId !== u.id) fail(404, "Playlist não encontrada.");
    const b = await ctx.json();
    const partial = {};
    for (const k of ["name", "description", "coverKey"]) if (b[k] !== undefined) partial[k] = b[k];
    if (Array.isArray(b.songIds)) partial.songIds = b.songIds.slice(0, 500);
    if (b.visibility && b.visibility !== (p.visibility || "private")) {
      partial.visibility = b.visibility === "shared" ? "shared" : "private";
      partial.adminStatus = statusFor(partial.visibility, p.adminStatus);
      partial.history = logUp(p, partial.visibility === "shared" ? (partial.adminStatus === "pending" ? "share_request" : "share") : "make_private", "owner");
    }
    return { playlist: upOut(docs.patch(UP, p.id, partial), u.id) };
  });
  r.delete("/api/user-playlists/:id", (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (p && (p.ownerId === u.id || u.role === "admin")) docs.del(UP, p.id);
    return { ok: true };
  });
  const toggleSave = (save) => (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    const set = new Set(p.savedBy || []);
    save ? set.add(u.id) : set.delete(u.id);
    return { playlist: upOut(docs.patch(UP, p.id, { savedBy: [...set] }), u.id) };
  };
  r.post("/api/user-playlists/:id/save", toggleSave(true));
  r.delete("/api/user-playlists/:id/save", toggleSave(false));
  r.post("/api/user-playlists/:id/play", (ctx) => {
    requireUser(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (p) docs.patch(UP, p.id, { plays: (p.plays || 0) + 1 });
    return { ok: true };
  });
  r.post("/api/user-playlists/cover", async (ctx) => {
    requireUser(ctx);
    const { saveCover } = await import("../util.js");
    const buf = await ctx.raw(10 * 1024 * 1024);
    const key = saveCover(buf, ctx.req.headers["content-type"] || "image/jpeg");
    return { key, url: coverUrl(key) };
  });
  const adminList = (ctx) => {
    const u = requireAdmin(ctx);
    const items = docs.list(UP).map((p) => upOut(p, u.id));
    const counts = { all: items.length, private: 0, pending: 0, approved: 0, rejected: 0, removed: 0 };
    for (const i of items) counts[i.adminStatus] = (counts[i.adminStatus] || 0) + 1;
    return { settings: upSettings(), items, counts, total: items.length };
  };
  r.get("/api/admin/user-playlists", adminList);
  r.put("/api/admin/user-playlists/settings", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const next = { ...upSettings() };
    for (const k of ["creation", "sharing", "requireApproval"]) if (typeof b[k] === "boolean") next[k] = b[k];
    kvSet("user-playlists:settings", next);
    return { settings: next };
  });
  r.get("/api/admin/user-playlists/pending", (ctx) => { requireAdmin(ctx); return { pending: docs.list(UP).filter((p) => p.visibility === "shared" && p.adminStatus === "pending").length }; });
  r.get("/api/admin/user-playlists/:id", (ctx) => { const u = requireAdmin(ctx); const p = docs.get(UP, ctx.params.id); if (!p) fail(404, "Playlist não encontrada."); return { playlist: upOut(p, u.id) }; });
  r.delete("/api/admin/user-playlists/:id", (ctx) => { requireAdmin(ctx); docs.del(UP, ctx.params.id); return { ok: true }; });
  r.post("/api/admin/user-playlists/:id/:action", async (ctx) => {
    const u = requireAdmin(ctx);
    const p = docs.get(UP, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    const b = await ctx.json();
    const a = ctx.params.action;
    const partial = { adminNote: b.note || null, history: logUp(p, a, "admin") };
    if (a === "approve") partial.adminStatus = "approved";
    else if (a === "reject") partial.adminStatus = "rejected";
    else if (a === "hide") partial.hidden = true;
    else if (a === "unhide") partial.hidden = false;
    else if (a === "unshare") partial.adminStatus = "removed";
    else fail(400, "Ação inválida.");
    return { playlist: upOut(docs.patch(UP, p.id, partial), u.id) };
  });
  r.put("/api/admin/user-playlists/visibility", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    for (const id of b.ids || []) docs.patch(UP, id, { hidden: !!b.hidden });
    return { changed: (b.ids || []).length };
  });

  // ---------------- Suporte ----------------
  const T = "tickets";
  const CATS = { duvida: "Dúvida", tecnico: "Problema técnico", pagamento: "Pagamento", plano: "Plano", biblioteca: "Música / biblioteca",
    playlist: "Playlist", radio: "Rádio", publicidade: "Publicidade", conta: "Conta", outro: "Outro" };
  const STATUSES = ["open", "in_review", "waiting_user", "answered", "resolved", "closed"];
  const STATUS_LABEL = { open: "Aberto", in_review: "Em análise", waiting_user: "Aguardando usuário", answered: "Respondido", resolved: "Resolvido", closed: "Fechado" };
  const ticketSummary = (t, viewer) => {
    const u = users.byId(t.userId);
    return { id: t.id, code: t.code, subject: t.subject, category: t.category, categoryLabel: CATS[t.category] || "Outro",
      status: t.status, createdAt: t.createdAt, updatedAt: t.updatedAt || t.createdAt,
      unread: viewer === "admin" ? !!t.unreadStaff : !!t.unreadUser,
      userId: t.userId, userName: u?.displayName || "", userEmail: u?.email || "", user: u ? { id: u.id, name: u.displayName, email: u.email } : null,
      messageCount: (t.messages || []).filter((m) => m.kind === "message").length };
  };
  const msgOut = (m) => ({ ...m, attachmentUrl: m.attachmentKey ? `/api/files/${m.attachmentKey}` : null });
  const ticketFull = (t, viewer) => ({ ticket: { ...ticketSummary(t, viewer), notes: t.notes || "" },
    messages: (t.messages || []).filter((m) => viewer === "admin" || m.kind !== "note").map(msgOut) });
  const event = (body) => ({ id: uuid(), kind: "event", body, createdAt: now() });
  const getTicket = (ctx) => {
    const t = docs.get(T, ctx.params.id);
    if (!t || (t.userId !== ctx.user.id && ctx.user.role !== "admin")) fail(404, "Ticket não encontrado.");
    return t;
  };

  r.get("/api/support/tickets", (ctx) => { const u = requireUser(ctx); return docs.list(T).filter((t) => t.userId === u.id).map((t) => ticketSummary(t, "user")); });
  r.get("/api/support/summary", (ctx) => {
    const u = requireUser(ctx);
    const mine = docs.list(T).filter((t) => t.userId === u.id);
    return { active: mine.filter((t) => ["open", "in_review", "waiting_user", "answered"].includes(t.status)).length,
      unread: mine.filter((t) => t.unreadUser).length, total: mine.length };
  });
  r.post("/api/support/tickets", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    const subject = String(b.subject || "").trim();
    const body = String(b.body || b.message || "").trim();
    if (subject.length < 4) fail(400, "Informe o assunto (pelo menos 4 caracteres).");
    if (body.length < 10) fail(400, "Explique o que aconteceu (pelo menos 10 caracteres).");
    const t = now();
    const doc = docs.put(T, uuid(), { userId: u.id, subject: subject.slice(0, 120), category: CATS[b.category] ? b.category : "outro",
      status: "open", unreadStaff: true, unreadUser: false, code: String(Date.now()).slice(-6),
      messages: [{ id: uuid(), kind: "message", author: "user", body: body.slice(0, 5000), attachmentKey: b.attachmentKey || null, createdAt: t }],
      createdAt: t }, u.id);
    return ticketFull(doc, "user");
  });
  r.get("/api/support/tickets/:id", (ctx) => {
    requireUser(ctx);
    const t = getTicket(ctx);
    if (t.userId === ctx.user.id && t.unreadUser) docs.patch(T, t.id, { unreadUser: false });
    return ticketFull(docs.get(T, t.id), "user");
  });
  r.post("/api/support/tickets/:id/messages", async (ctx) => {
    requireUser(ctx);
    const t = getTicket(ctx);
    const b = await ctx.json();
    if (!String(b.body || "").trim() && !b.attachmentKey) fail(400, "Escreva uma mensagem.");
    const msg = { id: uuid(), kind: "message", author: "user", body: String(b.body || "").slice(0, 5000), attachmentKey: b.attachmentKey || null, createdAt: now() };
    return ticketFull(docs.patch(T, t.id, { messages: [...(t.messages || []), msg], status: "open", unreadStaff: true }), "user");
  });
  r.post("/api/support/tickets/:id/reopen", (ctx) => {
    requireUser(ctx);
    const t = getTicket(ctx);
    return ticketFull(docs.patch(T, t.id, { status: "open", unreadStaff: true, messages: [...(t.messages || []), event("Ticket reaberto pelo usuário")] }), "user");
  });
  r.post("/api/support/attachments", async (ctx) => {
    requireUser(ctx);
    const buf = await ctx.raw(6 * 1024 * 1024);
    const f = saveFile(buf, "image/jpeg", "anexo.jpg");
    return { ...f, key: f.key, url: f.url };
  });

  r.get("/api/admin/support/tickets", (ctx) => {
    requireAdmin(ctx);
    const status = ctx.query.get("status");
    const q = (ctx.query.get("q") || "").toLowerCase();
    return docs.list(T).filter((t) => !status || t.status === status).map((t) => ticketSummary(t, "admin"))
      .filter((t) => !q || `${t.subject} ${t.code} ${t.userName} ${t.userEmail}`.toLowerCase().includes(q));
  });
  r.get("/api/admin/support/summary", (ctx) => {
    requireAdmin(ctx);
    const all = docs.list(T);
    const counts = Object.fromEntries(STATUSES.map((s) => [s, all.filter((t) => t.status === s).length]));
    return { counts, pending: all.filter((t) => t.status === "open" || t.status === "in_review").length, unread: all.filter((t) => t.unreadStaff).length };
  });
  r.get("/api/admin/support/tickets/:id", (ctx) => {
    requireAdmin(ctx);
    const t = getTicket(ctx);
    if (t.unreadStaff) docs.patch(T, t.id, { unreadStaff: false });
    return ticketFull(docs.get(T, t.id), "admin");
  });
  r.post("/api/admin/support/tickets/:id/messages", async (ctx) => {
    requireAdmin(ctx);
    const t = getTicket(ctx);
    const b = await ctx.json();
    const msgs = [...(t.messages || [])];
    if (String(b.body || "").trim() || b.attachmentKey) {
      msgs.push({ id: uuid(), kind: b.internal || b.kind === "note" ? "note" : "message", author: "staff",
        body: String(b.body || "").slice(0, 5000), attachmentKey: b.attachmentKey || null, createdAt: now() });
    }
    const status = STATUSES.includes(b.status) ? b.status : "answered";
    if (status !== t.status) msgs.push(event(`Status alterado para ${STATUS_LABEL[status]}`));
    return ticketFull(docs.patch(T, t.id, { messages: msgs, status, unreadUser: true }), "admin");
  });
  const adminTicketUpdate = async (ctx) => {
    requireAdmin(ctx);
    const t = getTicket(ctx);
    const b = await ctx.json();
    const partial = {};
    const msgs = [...(t.messages || [])];
    if (STATUSES.includes(b.status) && b.status !== t.status) { partial.status = b.status; msgs.push(event(`Status alterado para ${STATUS_LABEL[b.status]}`)); partial.unreadUser = true; }
    if (b.category && CATS[b.category]) partial.category = b.category;
    if (typeof b.notes === "string") partial.notes = b.notes;
    if (typeof b.note === "string" && b.note.trim()) msgs.push({ id: uuid(), kind: "note", author: "staff", body: b.note.trim(), createdAt: now() });
    partial.messages = msgs;
    return ticketFull(docs.patch(T, t.id, partial), "admin");
  };
  r.patch("/api/admin/support/tickets/:id", adminTicketUpdate);
  r.post("/api/admin/support/tickets/:id/:action", adminTicketUpdate);

  // ---------------- Avisos ----------------
  r.get("/api/notices", (ctx) => { requireUser(ctx); return { notices: [], unread: 0, home: null, popup: null, periodDays: 7 }; });
  r.post("/api/notices/read", (ctx) => { requireUser(ctx); return { ok: true }; });
  r.post("/api/notices/:id/dismiss", (ctx) => { requireUser(ctx); return { ok: true }; });
}
