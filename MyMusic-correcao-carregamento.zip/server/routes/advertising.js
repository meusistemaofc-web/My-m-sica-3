// Publicidade paga: pacotes, página de vendas, pedidos com Pix (Mercado Pago), aprovação e exibição no app.
import { docs, users, kvGet, kvSet, now } from "../db.js";
import { fail } from "../http.js";
import { requireUser, requireAdmin } from "../auth.js";
import { uuid, coverUrl, saveCover } from "../util.js";
import { mpCreatePix, mpCancelPayment, mpConfig } from "../mercadopago.js";
import { onPaymentChange, pixAvailability, recordPayment, applyMpPayment, syncPayment, paymentOut } from "./payments.js";

const ORD = "ad-orders";
const PKG = "ad-packages";
const PAY = "payments";
const MAX_IMAGE_LIMIT = 15 * 1024 * 1024;
const DAY = 86400e3;

const FORMATS = [
  { key: "jpeg", label: "JPG" }, { key: "png", label: "PNG" }, { key: "webp", label: "WEBP" }, { key: "gif", label: "GIF" },
];
const MIME = { jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif" };
const LIMITS = { seconds: { min: 3, max: 60 }, minutes: { min: 1, max: 120 } };

// ------------------------------------------------------------------ configurações
const DEFAULTS = {
  usersAvailable: true, enabled: true, showInMenu: true, menuLabel: "Divulgue seu negócio",
  duration: { enabled: false, minDays: 1, maxDays: 30, pricing: "package", pricePerDayCents: 1000, tiers: [] },
  geo: { enabled: false, modes: ["br", "state", "cities", "custom"], states: [] },
  maxImageBytes: 5 * 1024 * 1024, maxActive: null, formats: ["jpeg", "png", "webp"], pauseRule: "freeze",
  display: { displaySeconds: 5, intervalMinutes: 5, autoDisplay: true, rotation: true, order: "auto", manualOrder: [] },
  notify: { advertiserPush: true, advertiserEmail: false, adminPush: true },
};
function deepMerge(a, b) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b || {})) {
    out[k] = v && typeof v === "object" && !Array.isArray(v) && a[k] && typeof a[k] === "object" && !Array.isArray(a[k]) ? deepMerge(a[k], v) : v;
  }
  return out;
}
export const adSettings = () => deepMerge(DEFAULTS, kvGet("ads:settings", {}));
const globalAds = () => ({ enabled: true, usersEnabled: true, updatedAt: null, ...kvGet("ads:global", {}) });

// ------------------------------------------------------------------ página de vendas
const sid = () => Math.random().toString(36).slice(2, 10);
const section = (type, extra) => ({ id: `secao-${sid()}`, type, enabled: true, eyebrow: "", title: "", subtitle: "", text: "",
  imageKey: null, imagePosition: "right", primary: { text: "", link: "" }, secondary: { text: "", link: "" }, items: [], ...extra });
const item = (title, text, icon = "sparkles") => ({ id: sid(), icon, title, text, imageKey: null });
function defaultPage() {
  return {
    sections: [
      section("hero", { eyebrow: "Publicidade", title: "Divulgue seu negócio para quem ouve música todo dia",
        subtitle: "Seu anúncio aparece em tela cheia para os ouvintes do My Music.",
        primary: { text: "Criar meu anúncio", link: "/publicidade/novo" }, secondary: { text: "Ver planos", link: "#planos" } }),
      section("steps", { title: "Como funciona", items: [
        item("Escolha o pacote", "Selecione por quantos dias sua publicidade fica no ar.", "calendar"),
        item("Envie sua arte", "Imagem, título, descrição e o link do seu botão.", "sparkles"),
        item("Pague com Pix", "Pagamento único e confirmado na hora pelo Mercado Pago.", "qr"),
        item("Aprovação e publicação", "Nossa equipe avalia e publica o anúncio.", "rocket")] }),
      { ...section("plans", { title: "Planos de publicidade", primary: { text: "Contratar", link: "/publicidade/novo" } }), id: "planos" },
      section("faq", { title: "Perguntas frequentes", items: [
        item("Quando meu anúncio começa?", "Depois do pagamento confirmado e da aprovação do administrador."),
        item("E se o anúncio for recusado?", "Você recebe o motivo. Fale com a gente sobre o reembolso.")] }),
    ],
    footer: { enabled: false, title: "Fale com a gente", text: "", email: "", whatsapp: "", phone: "", website: "", instagram: "", address: "" },
  };
}
function pageState() {
  const p = kvGet("ads:page", null);
  if (p) return p;
  const d = defaultPage();
  return { draft: d, published: d, updatedAt: null, publishedAt: null };
}

// ------------------------------------------------------------------ pacotes e preços
function pkgOut(p) {
  const s = adSettings();
  const d = s.duration;
  return { active: true, featured: false, sortOrder: 0, icon: "megaphone", benefits: [], description: "", ...p,
    imageUrl: coverUrl(p.imageKey),
    effectiveMaxImageBytes: p.maxImageBytes || s.maxImageBytes,
    customDuration: d.enabled ? { min: d.minDays, max: d.maxDays } : null };
}
const activePackages = () => docs.list(PKG).filter((p) => p.active !== false).map(pkgOut).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0) || a.priceCents - b.priceCents);

/** Mesmo cálculo de preço usado na tela (duração do pacote ou personalizada). */
function quote(pkg, days) {
  if (!days || days === pkg.durationDays) return { days: pkg.durationDays, priceCents: pkg.priceCents, custom: false };
  const d = adSettings().duration;
  if (!d.enabled || days < d.minDays || days > d.maxDays || !Number.isInteger(days)) return null;
  let cents;
  if (d.pricing === "per_day") cents = d.pricePerDayCents * days;
  else if (d.pricing === "tiers") {
    const tier = [...(d.tiers || [])].sort((a, b) => a.upToDays - b.upToDays).find((t) => days <= t.upToDays);
    if (!tier) return null;
    cents = tier.pricePerDayCents * days;
  } else cents = (pkg.priceCents * days) / pkg.durationDays;
  return { days, priceCents: Math.max(100, Math.round(cents)), custom: true };
}

// ------------------------------------------------------------------ pedidos
const GEO_LABEL = { all: "Todas as regiões", br: "Brasil inteiro", state: "Estados escolhidos", cities: "Cidades escolhidas", custom: "Região personalizada" };
function geoSummary(g) {
  if (!g || g.mode === "all") return ["Todas as regiões: qualquer ouvinte, com ou sem localização."];
  const out = [GEO_LABEL[g.mode] || "Região personalizada"];
  if (g.states?.length) out.push(`Estados: ${g.states.join(", ")}`);
  if (g.cities?.length) out.push(`Cidades: ${g.cities.map((c) => `${c.name}/${c.uf}`).join(", ")}`);
  if (g.regions?.length) out.push(`Regiões: ${g.regions.join(", ")}`);
  return out;
}

function displayStatus(o) {
  if (o.status !== "approved") return o.status;
  const t = Date.now();
  if (o.startsAt && new Date(o.startsAt).getTime() > t) return "scheduled";
  if (o.endsAt && new Date(o.endsAt).getTime() <= t) return "ended";
  return "active";
}
/** Encerra automaticamente pedidos cujo período terminou. */
function refresh(o) {
  if (o.status === "approved" && o.endsAt && new Date(o.endsAt).getTime() <= Date.now()) {
    return docs.patch(ORD, o.id, { status: "ended", endReason: "expired", endedAt: o.endsAt, events: event(o, "expired") });
  }
  return o;
}
const event = (o, action, note = null, actor = null) => [...(o.events || []), { id: uuid(), action, note, actor, createdAt: now() }];

function orderOut(raw, viewer = "user") {
  const o = refresh(raw);
  const ds = displayStatus(o);
  const pay = o.paymentId ? docs.get(PAY, o.paymentId) : null;
  const owner = users.byId(o.userId);
  const advertiser = o.companyName || o.advertiserName;
  const live = ds === "active";
  const out = {
    id: o.id, userId: o.userId, advertiserName: o.advertiserName, companyName: o.companyName || "", email: o.email, whatsapp: o.whatsapp || "",
    advertiser, packageId: o.packageId, packageName: o.packageName, durationDays: o.durationDays, durationCustom: !!o.durationCustom,
    priceCents: o.priceCents, amountPaidCents: o.amountPaidCents || (pay?.status === "approved" ? pay.amountCents : o.priceCents),
    title: o.title, description: o.description, buttonText: o.buttonText, buttonUrl: o.buttonUrl,
    mediaType: "image", imageUrl: coverUrl(o.imageKey), imageBytes: o.imageBytes || null, imageType: o.imageType || null, videoUrl: null,
    geo: o.geo || null, geoLabel: geoSummary(o.geo)[0], geoSummary: geoSummary(o.geo),
    geoEditable: ["awaiting_payment", "pending_review", "changes_requested", "approved", "paused"].includes(o.status) && !!adSettings().geo.enabled,
    regional: !!o.geo && o.geo.mode !== "all",
    status: o.status, displayStatus: ds, live, reviewNote: o.reviewNote || null,
    paidAt: o.paidAt || null, startsAt: o.startsAt || null, endsAt: o.endsAt || null, endReason: o.endReason || null, endedAt: o.endedAt || null,
    pausedBy: o.pausedBy || null, remainingMs: o.remainingMs ?? (o.endsAt ? Math.max(0, new Date(o.endsAt).getTime() - Date.now()) : null),
    editable: o.status === "awaiting_payment" || o.status === "changes_requested",
    canPause: live, canResume: o.status === "paused" && o.pausedBy === "user",
    resubmitted: !!o.resubmitted, views: o.views || 0, clicks: o.clicks || 0,
    payment: pay ? paymentOut(pay) : null, paymentStatus: pay?.status || null,
    account: owner ? { id: owner.id, name: owner.displayName, email: owner.email } : null,
    createdAt: o.createdAt, updatedAt: o.updatedAt || o.createdAt,
  };
  return out;
}
const detail = (o, viewer) => ({ order: orderOut(o, viewer), events: (refresh(o).events || []).slice().reverse(),
  reach: { total: o.views || 0 }, audience: null });

function validateOrder(b, { partial = false } = {}) {
  const err = (m) => fail(400, m);
  const s = adSettings();
  const out = {};
  const str = (k, max) => (b[k] === undefined ? undefined : String(b[k] || "").trim().slice(0, max));
  for (const [k, max] of [["advertiserName", 120], ["companyName", 120], ["email", 160], ["whatsapp", 20], ["title", 80], ["description", 400], ["buttonText", 30], ["buttonUrl", 500]]) {
    const v = str(k, max);
    if (v !== undefined) out[k] = v;
  }
  if (!partial || out.advertiserName !== undefined) if ((out.advertiserName || "").length < 2) err("Informe o nome completo ou o nome da empresa.");
  if (!partial || out.email !== undefined) if (!/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]{2,}$/.test(out.email || "")) err("Informe um e-mail de contato válido.");
  if (!partial || out.title !== undefined) if ((out.title || "").length < 3) err("Informe o nome do anúncio (pelo menos 3 caracteres).");
  if (!partial || out.description !== undefined) if ((out.description || "").length < 10) err("Escreva a descrição do anúncio (pelo menos 10 caracteres).");
  if (out.buttonUrl !== undefined) {
    let u = out.buttonUrl;
    if (u && !/^[a-z][a-z0-9+.-]*:/i.test(u)) u = `https://${u}`;
    try { const x = new URL(u); if (!/^https?:$/.test(x.protocol) || !x.hostname.includes(".")) throw 0; out.buttonUrl = x.toString(); }
    catch { err("Link de destino inválido. Use um endereço completo, por exemplo https://www.suaempresa.com.br."); }
  }
  if (out.whatsapp !== undefined) out.whatsapp = out.whatsapp.replace(/\D/g, "").replace(/^55(?=\d{10,11}$)/, "");
  if (b.geo !== undefined) out.geo = b.geo && b.geo.mode && b.geo.mode !== "all" && s.geo.enabled ? b.geo : null;
  if (b.packageId !== undefined) {
    const pkg = docs.get(PKG, b.packageId);
    if (!pkg || pkg.active === false) err("Escolha o pacote de divulgação.");
    const q = quote(pkg, Number(b.durationDays) || pkg.durationDays);
    if (!q) err("A duração escolhida não está disponível para este pacote.");
    Object.assign(out, { packageId: pkg.id, packageName: pkg.name, durationDays: q.days, durationCustom: q.custom, priceCents: q.priceCents });
  }
  return out;
}

function detectImage(buf) {
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpeg";
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf.slice(0, 3).toString() === "GIF") return "gif";
  if (buf.slice(0, 4).toString() === "RIFF" && buf.slice(8, 12).toString() === "WEBP") return "webp";
  return null;
}

// ------------------------------------------------------------------ pagamento confirmado
onPaymentChange("ad", async (pay, prev) => {
  const ids = pay.orderIds || [pay.refId];
  for (const id of ids) {
    const o = docs.get(ORD, id);
    if (!o) continue;
    if (pay.status === "approved" && o.status === "awaiting_payment") {
      docs.patch(ORD, o.id, { status: "pending_review", paidAt: pay.approvedAt || now(), amountPaidCents: pay.amountCents, paymentId: pay.id, events: event(o, "paid") });
    } else if (["refunded", "charged_back"].includes(pay.status) && prev !== pay.status && ["pending_review", "changes_requested", "approved", "paused"].includes(o.status)) {
      docs.patch(ORD, o.id, { status: "ended", endReason: "refunded", endedAt: now(), events: event(o, "refunded") });
    }
  }
  if (pay.status === "approved" && !pay.processed) docs.patch(PAY, pay.id, { processed: true });
});

// ------------------------------------------------------------------ informações públicas
function infoFor(u) {
  const s = adSettings();
  const visible = s.usersAvailable || u.role === "admin";
  return {
    available: visible, enabled: !!s.enabled && visible, canOrder: u.role !== "admin",
    showInMenu: !!s.showInMenu && visible, menuLabel: s.menuLabel,
    packages: activePackages(), pix: pixAvailability(),
    page: visible ? pageState().published : null,
    formats: FORMATS.filter((f) => s.formats.includes(f.key)), maxImageBytes: s.maxImageBytes,
    duration: s.duration.enabled ? s.duration : null,
    geo: { enabled: !!s.geo.enabled, modes: s.geo.enabled ? ["all", ...s.geo.modes] : ["all"], states: s.geo.states, limitedStates: s.geo.states.length > 0 },
    video: { usersEnabled: false },
    reason: visible ? null : "account", message: visible ? null : "A Publicidade não está disponível no momento.",
  };
}

function adminSettingsView() {
  const s = adSettings();
  const pix = pixAvailability();
  const queue = docs.list(ORD).map((o) => orderOut(o, "admin")).filter((o) => ["active", "scheduled", "paused"].includes(o.displayStatus))
    .map((o) => ({ id: o.id, title: o.title, advertiser: o.advertiser, packageName: o.packageName, imageUrl: o.imageUrl, isVideo: false,
      startsAt: o.startsAt, endsAt: o.endsAt, live: o.live, status: o.displayStatus }));
  const order = s.display.order === "manual" ? s.display.manualOrder : [];
  queue.sort((a, b) => (order.indexOf(a.id) + 1 || 1e9) - (order.indexOf(b.id) + 1 || 1e9) || (a.startsAt || "").localeCompare(b.startsAt || ""));
  return { settings: s, formats: FORMATS, pix: { available: pix.available, mode: pix.mode, reason: pix.reason },
    channels: { push: false, email: false }, maxImageLimitBytes: MAX_IMAGE_LIMIT, maxLimitBytes: MAX_IMAGE_LIMIT,
    displayLimits: LIMITS, queue };
}

function liveAds() {
  const g = globalAds();
  const s = adSettings();
  const display = { ...s.display };
  if (!g.enabled || !g.usersEnabled) return { ads: [], display };
  const q = adminSettingsView().queue.filter((x) => x.live).map((x) => docs.get(ORD, x.id)).filter((o) => o && (!o.geo || o.geo.mode === "all"));
  return { display, ads: q.map((o) => ({ id: o.id, title: o.title, description: o.description, imageUrl: coverUrl(o.imageKey), videoUrl: null,
    mediaType: "image", buttonText: o.buttonText, buttonUrl: o.buttonUrl, advertiser: o.companyName || o.advertiserName,
    startsAt: o.startsAt, endsAt: o.endsAt })) };
}

// ------------------------------------------------------------------ rotas
export function registerAdvertising(r) {
  // --- chave geral de anúncios ---
  const globalView = () => {
    const all = docs.list(ORD).map((o) => orderOut(o, "admin"));
    return { ...globalAds(), overview: {
      liveSponsored: all.filter((o) => o.displayStatus === "active").length,
      pendingReview: all.filter((o) => o.status === "pending_review").length,
      pausedSponsored: all.filter((o) => o.status === "paused").length, floatingActive: 0, audioActive: 0 } };
  };
  r.get("/api/ads-global", (ctx) => { requireUser(ctx); return globalView(); });
  r.put("/api/ads-global", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const cur = globalAds();
    kvSet("ads:global", { ...cur, ...(typeof b.enabled === "boolean" ? { enabled: b.enabled } : {}),
      ...(typeof b.usersEnabled === "boolean" ? { usersEnabled: b.usersEnabled } : {}), updatedAt: now() });
    return globalView();
  });

  // --- usuário ---
  r.get("/api/advertising", (ctx) => infoFor(requireUser(ctx)));

  r.post("/api/advertising/audience", async (ctx) => {
    requireUser(ctx);
    const b = await ctx.json();
    return !b.target || b.target.mode === "all" ? { kind: "all" } : { kind: "none", count: 0 };
  });

  r.get("/api/advertising/orders", (ctx) => {
    const u = requireUser(ctx);
    return docs.list(ORD).filter((o) => o.userId === u.id).map((o) => orderOut(o));
  });

  r.post("/api/advertising/orders", async (ctx) => {
    const u = requireUser(ctx);
    if (u.role === "admin") fail(403, "A conta de administrador gerencia os anúncios no painel administrativo.");
    const s = adSettings();
    if (!s.enabled || !s.usersAvailable) fail(403, "A contratação de anúncios está pausada no momento.");
    const b = await ctx.json();
    const data = validateOrder(b);
    if (!data.packageId) fail(400, "Escolha o pacote de divulgação.");
    if (!data.buttonText || data.buttonText.length < 2) fail(400, "Informe o texto do botão de ação.");
    if (!data.buttonUrl) fail(400, "Informe o link de destino do botão.");
    const doc = { ...data, userId: u.id, status: "awaiting_payment", views: 0, clicks: 0, createdAt: now(), events: [] };
    doc.events = event(doc, "created");
    const o = docs.put(ORD, uuid(), doc, u.id);
    return detail(o);
  });

  const own = (ctx) => {
    const u = requireUser(ctx);
    const o = docs.get(ORD, ctx.params.id);
    if (!o || (o.userId !== u.id && u.role !== "admin")) fail(404, "Anúncio não encontrado.");
    return o;
  };

  r.get("/api/advertising/orders/:id", (ctx) => detail(own(ctx)));

  r.patch("/api/advertising/orders/:id", async (ctx) => {
    const o = own(ctx);
    if (!["awaiting_payment", "changes_requested"].includes(o.status)) fail(409, "Este anúncio não pode mais ser editado.");
    const b = await ctx.json();
    if (o.status === "changes_requested") { delete b.packageId; delete b.durationDays; }
    const data = validateOrder(b, { partial: true });
    if (o.status === "awaiting_payment" && data.priceCents && data.priceCents !== o.priceCents && o.paymentId) {
      const p = docs.get(PAY, o.paymentId);
      if (p?.status === "pending") { try { await applyMpPayment(p, await mpCancelPayment(p.mpPaymentId)); } catch {} }
    }
    return detail(docs.patch(ORD, o.id, data));
  });

  r.put("/api/advertising/orders/:id/image", async (ctx) => {
    const o = own(ctx);
    if (!["awaiting_payment", "changes_requested"].includes(o.status)) fail(409, "A imagem não pode mais ser trocada.");
    const s = adSettings();
    const pkg = docs.get(PKG, o.packageId);
    const max = pkg?.maxImageBytes || s.maxImageBytes;
    const buf = await ctx.raw(MAX_IMAGE_LIMIT + 1024);
    if (!buf.length) fail(400, "Envie a imagem do anúncio.");
    if (buf.length > max) fail(413, `A imagem tem ${(buf.length / 1048576).toFixed(1)} MB e o limite é ${(max / 1048576).toFixed(1)} MB.`);
    const fmt = detectImage(buf);
    if (!fmt || !s.formats.includes(fmt)) fail(400, `Formato não aceito. Envie ${FORMATS.filter((f) => s.formats.includes(f.key)).map((f) => f.label).join(", ")}.`);
    const key = saveCover(buf, MIME[fmt]);
    return detail(docs.patch(ORD, o.id, { imageKey: key, imageBytes: buf.length, imageType: MIME[fmt] }));
  });

  r.put("/api/advertising/orders/:id/video", (ctx) => { own(ctx); fail(400, "Os anúncios com vídeo estão desativados. Use uma imagem."); });

  r.put("/api/advertising/orders/:id/geo", async (ctx) => {
    const o = own(ctx);
    const b = await ctx.json();
    const geo = b.geo && b.geo.mode && b.geo.mode !== "all" && adSettings().geo.enabled ? b.geo : null;
    return detail(docs.patch(ORD, o.id, { geo, events: event(o, "geo") }));
  });

  r.get("/api/advertising/orders/:id/reach", (ctx) => {
    const o = own(ctx);
    return { total: o.views || 0, states: { rows: [], hidden: 0, hiddenGroups: 0 }, cities: { rows: [], hidden: 0, hiddenGroups: 0 } };
  });

  r.post("/api/advertising/orders/:id/sync", async (ctx) => {
    const o = own(ctx);
    const p = o.paymentId ? docs.get(PAY, o.paymentId) : null;
    if (p) await syncPayment(p);
    return detail(docs.get(ORD, o.id));
  });

  r.post("/api/advertising/orders/:id/:action", async (ctx) => {
    const u = requireUser(ctx);
    const o = own(ctx);
    const a = ctx.params.action;
    const pay = o.paymentId ? docs.get(PAY, o.paymentId) : null;

    if (a === "pix") {
      if (o.status !== "awaiting_payment") fail(409, "Este anúncio não está aguardando pagamento.");
      const s = adSettings();
      if (!s.enabled) fail(403, "A contratação de anúncios está pausada no momento.");
      const pix = pixAvailability();
      if (!pix.available) fail(400, pix.reason);
      if (!o.imageKey) fail(400, "Envie a imagem do anúncio antes de pagar.");
      if (pay && pay.status === "pending" && pay.checkoutData?.expiresAt && new Date(pay.checkoutData.expiresAt) > new Date() && pay.amountCents === o.priceCents) {
        return detail(o);
      }
      if (pay && pay.status === "pending") { try { await applyMpPayment(pay, await mpCancelPayment(pay.mpPaymentId)); } catch {} }
      const ref = uuid();
      const mp = await mpCreatePix({ amountCents: o.priceCents, description: `Publicidade: ${o.title} (${o.packageName})`,
        email: o.email, name: o.advertiserName, externalReference: ref, req: ctx.req });
      const rec = recordPayment({ kind: "ad", refId: o.id, userId: o.userId, amountCents: o.priceCents, mp, mode: mpConfig()?.mode || "test",
        extra: { orderIds: [o.id], title: o.title, packageName: o.packageName } });
      docs.patch(ORD, o.id, { paymentId: rec.id });
      if (mp.status === "approved") await applyMpPayment(rec, mp);
      return detail(docs.get(ORD, o.id));
    }
    if (a === "cancel-pix") {
      if (pay && ["pending", "in_process"].includes(pay.status)) {
        try { await applyMpPayment(pay, await mpCancelPayment(pay.mpPaymentId)); } catch (e) { await syncPayment(pay).catch(() => {}); }
      }
      return detail(docs.get(ORD, o.id));
    }
    if (a === "cancel") {
      if (o.status !== "awaiting_payment") fail(409, "Só é possível cancelar pedidos que ainda não foram pagos.");
      if (pay && pay.status === "pending") { try { await applyMpPayment(pay, await mpCancelPayment(pay.mpPaymentId)); } catch {} }
      const fresh = docs.get(ORD, o.id);
      if (fresh.status !== "awaiting_payment") return detail(fresh);
      return detail(docs.patch(ORD, o.id, { status: "cancelled", events: event(fresh, "cancelled") }));
    }
    if (a === "resubmit") {
      if (o.status !== "changes_requested") fail(409, "Este anúncio não está aguardando correção.");
      if (!o.imageKey) fail(400, "Envie a imagem do anúncio.");
      return detail(docs.patch(ORD, o.id, { status: "pending_review", resubmitted: true, events: event(o, "resubmitted") }));
    }
    if (a === "pause") {
      if (displayStatus(o) !== "active") fail(409, "Só é possível pausar uma publicidade no ar.");
      return detail(docs.patch(ORD, o.id, pauseData(o, "user")));
    }
    if (a === "resume") {
      if (o.status !== "paused" || o.pausedBy !== "user") fail(409, "Esta publicidade não pode ser reativada por você.");
      return detail(docs.patch(ORD, o.id, resumeData(o)));
    }
    fail(400, "Ação inválida.");
  });

  // --- exibição no app ---
  r.get("/api/advertising/live", (ctx) => { requireUser(ctx); return liveAds(); });
  r.post("/api/advertising/live/:id/view", (ctx) => {
    requireUser(ctx);
    const o = docs.get(ORD, ctx.params.id);
    if (o) docs.patch(ORD, o.id, { views: (o.views || 0) + 1 });
    return { ok: true };
  });
  r.post("/api/advertising/live/:id/click", (ctx) => {
    requireUser(ctx);
    const o = docs.get(ORD, ctx.params.id);
    if (o) docs.patch(ORD, o.id, { clicks: (o.clicks || 0) + 1 });
    return { ok: true };
  });

  // --- admin: configurações ---
  r.get("/api/admin/advertising/settings", (ctx) => { requireAdmin(ctx); return adminSettingsView(); });
  r.put("/api/admin/advertising/settings", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const cur = kvGet("ads:settings", {});
    const patch = { ...b };
    if (b.maxImageMb !== undefined) {
      const mb = Number(b.maxImageMb);
      if (!(mb > 0) || mb * 1048576 > MAX_IMAGE_LIMIT) fail(400, `O tamanho máximo deve ficar entre 0,1 e ${MAX_IMAGE_LIMIT / 1048576} MB.`);
      patch.maxImageBytes = Math.round(mb * 1048576);
      delete patch.maxImageMb;
    }
    if (b.maxActive !== undefined) patch.maxActive = b.maxActive ? Math.max(1, Number(b.maxActive)) : null;
    if (b.display) {
      const d = b.display;
      if (d.displaySeconds !== undefined && (d.displaySeconds < LIMITS.seconds.min || d.displaySeconds > LIMITS.seconds.max)) fail(400, "Tempo de exibição fora do limite.");
      if (d.intervalMinutes !== undefined && (d.intervalMinutes < LIMITS.minutes.min || d.intervalMinutes > LIMITS.minutes.max)) fail(400, "Intervalo fora do limite.");
    }
    kvSet("ads:settings", deepMerge(cur, patch));
    return adminSettingsView();
  });
  r.get("/api/admin/advertising/video", (ctx) => {
    requireAdmin(ctx);
    return { settings: { usersEnabled: false, maxUserBytes: 50 * 1048576, formats: ["mp4"], disabledRule: "pause" },
      usage: { files: 0, totalBytes: 0, userBytes: 0, adminBytes: 0, uploadingBytes: 0 } };
  });
  r.put("/api/admin/advertising/video", (ctx) => { requireAdmin(ctx); fail(400, "Anúncios com vídeo não estão disponíveis nesta instalação. Use imagens."); });
  r.get("/api/admin/advertising/geo", (ctx) => {
    requireAdmin(ctx);
    return { orders: docs.list(ORD).map((o) => orderOut(o, "admin")).filter((o) => o.regional && ["active", "scheduled", "paused"].includes(o.displayStatus))
      .map((o) => ({ ...o, eligible: 0, withLocation: 0, outsidePolicy: null })) };
  });

  // --- admin: pacotes ---
  r.get("/api/admin/advertising/packages", (ctx) => { requireAdmin(ctx); return docs.list(PKG).map(pkgOut).sort((a, b) => (a.sortOrder || 0) - (b.sortOrder || 0)); });
  const pkgData = (b, partial) => {
    const out = {};
    if (b.name !== undefined) { out.name = String(b.name).trim().slice(0, 60); if (!out.name) fail(400, "Informe o nome do pacote."); }
    if (b.description !== undefined) out.description = String(b.description || "").slice(0, 400);
    if (b.durationDays !== undefined) { out.durationDays = Number(b.durationDays); if (!Number.isInteger(out.durationDays) || out.durationDays < 1 || out.durationDays > 365) fail(400, "Duração inválida (1 a 365 dias)."); }
    if (b.priceCents !== undefined) { out.priceCents = Number(b.priceCents); if (!Number.isInteger(out.priceCents) || out.priceCents < 100) fail(400, "O preço mínimo é R$ 1,00."); }
    for (const k of ["icon", "imageKey", "featured", "active", "sortOrder", "benefits"]) if (b[k] !== undefined) out[k] = b[k];
    if (b.maxImageMb !== undefined) out.maxImageBytes = b.maxImageMb ? Math.round(Number(b.maxImageMb) * 1048576) : null;
    if (b.maxImageBytes !== undefined) out.maxImageBytes = b.maxImageBytes;
    if (!partial && (out.durationDays === undefined || out.priceCents === undefined)) fail(400, "Informe a duração e o preço do pacote.");
    return out;
  };
  r.post("/api/admin/advertising/packages", async (ctx) => { requireAdmin(ctx); return pkgOut(docs.put(PKG, uuid(), { active: true, ...pkgData(await ctx.json(), false), createdAt: now() })); });
  r.patch("/api/admin/advertising/packages/:id", async (ctx) => {
    requireAdmin(ctx);
    const p = docs.patch(PKG, ctx.params.id, pkgData(await ctx.json(), true));
    if (!p) fail(404, "Pacote não encontrado.");
    return pkgOut(p);
  });
  r.delete("/api/admin/advertising/packages/:id", (ctx) => {
    requireAdmin(ctx);
    if (docs.list(ORD).some((o) => o.packageId === ctx.params.id)) fail(409, "Este pacote já tem anúncios contratados. Para escondê-lo, desative o pacote.");
    docs.del(PKG, ctx.params.id);
    return { ok: true };
  });

  // --- admin: página de vendas ---
  r.get("/api/admin/advertising/page", (ctx) => { requireAdmin(ctx); return pageState(); });
  r.put("/api/admin/advertising/page", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    if (!Array.isArray(b.sections) || !b.footer) fail(400, "Conteúdo da página inválido.");
    const st = pageState();
    kvSet("ads:page", { ...st, draft: b, updatedAt: now() });
    return pageState();
  });
  r.post("/api/admin/advertising/page/publish", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const content = Array.isArray(b.sections) ? b : pageState().draft;
    kvSet("ads:page", { draft: content, published: content, updatedAt: now(), publishedAt: now() });
    return pageState();
  });
  r.post("/api/admin/advertising/page/discard", (ctx) => {
    requireAdmin(ctx);
    const st = pageState();
    kvSet("ads:page", { ...st, draft: st.published, updatedAt: now() });
    return pageState();
  });

  // --- admin: pedidos ---
  r.get("/api/admin/advertising/summary", (ctx) => {
    requireAdmin(ctx);
    const pending = docs.list(ORD).filter((o) => o.status === "pending_review").map((o) => orderOut(o, "admin"));
    return { pendingReview: pending.length, orders: ctx.query.get("list") ? pending.slice(0, 6) : [] };
  });
  r.get("/api/admin/advertising/orders", (ctx) => {
    requireAdmin(ctx);
    const q = ctx.query;
    const status = q.get("status");
    const text = (q.get("q") || "").toLowerCase();
    return docs.list(ORD).map((o) => orderOut(o, "admin"))
      .filter((o) => !status || o.displayStatus === status || o.status === status || (status === "approved" && ["scheduled", "active"].includes(o.displayStatus)))
      .filter((o) => !q.get("from") || o.createdAt >= q.get("from"))
      .filter((o) => !q.get("to") || o.createdAt.slice(0, 10) <= q.get("to"))
      .filter((o) => !text || `${o.title} ${o.advertiser} ${o.advertiserName} ${o.email}`.toLowerCase().includes(text));
  });
  r.get("/api/admin/advertising/orders/:id", (ctx) => {
    requireAdmin(ctx);
    const o = docs.get(ORD, ctx.params.id);
    if (!o) fail(404, "Anúncio não encontrado.");
    return detail(o, "admin");
  });
  r.post("/api/admin/advertising/orders/:id/:action", async (ctx) => {
    const admin = requireAdmin(ctx);
    const o = refresh(docs.get(ORD, ctx.params.id) || fail(404, "Anúncio não encontrado."));
    const b = await ctx.json();
    const note = String(b.note || b.text || "").trim().slice(0, 600) || null;
    const a = ctx.params.action;
    const actor = admin.displayName;
    if (a === "approve") {
      if (!["pending_review", "changes_requested"].includes(o.status)) fail(409, "Este anúncio não está aguardando avaliação.");
      const s = adSettings();
      if (s.maxActive) {
        const busy = docs.list(ORD).filter((x) => x.status === "approved" && ["active", "scheduled"].includes(displayStatus(x))).length;
        if (busy >= s.maxActive) fail(409, `Já existem ${busy} anúncios publicados ou agendados (limite de ${s.maxActive}).`);
      }
      const start = b.startsAt ? new Date(b.startsAt) : new Date();
      if (Number.isNaN(start.getTime())) fail(400, "Data de início inválida.");
      const startsAt = new Date(Math.max(start.getTime(), Date.now())).toISOString();
      const endsAt = new Date(new Date(startsAt).getTime() + o.durationDays * DAY).toISOString();
      return detail(docs.patch(ORD, o.id, { status: "approved", startsAt, endsAt, reviewNote: null, events: event(o, "approve", note, actor) }), "admin");
    }
    if (a === "reject" || a === "request_changes") {
      if (!["pending_review", "changes_requested"].includes(o.status)) fail(409, "Este anúncio não está aguardando avaliação.");
      if (!note) fail(400, a === "reject" ? "Informe o motivo da rejeição." : "Informe o que precisa ser corrigido.");
      return detail(docs.patch(ORD, o.id, { status: a === "reject" ? "rejected" : "changes_requested", reviewNote: note,
        resubmitted: false, events: event(o, a, note, actor) }), "admin");
    }
    if (a === "pause") {
      if (displayStatus(o) !== "active" && displayStatus(o) !== "scheduled") fail(409, "Só é possível pausar anúncios aprovados.");
      return detail(docs.patch(ORD, o.id, { ...pauseData(o, "admin"), events: event(o, "pause", note, actor) }), "admin");
    }
    if (a === "resume") {
      if (o.status !== "paused") fail(409, "Este anúncio não está pausado.");
      return detail(docs.patch(ORD, o.id, { ...resumeData(o), events: event(o, "resume", note, actor) }), "admin");
    }
    if (a === "end") {
      if (!["approved", "paused"].includes(o.status)) fail(409, "Este anúncio não está publicado.");
      return detail(docs.patch(ORD, o.id, { status: "ended", endReason: "admin", endedAt: now(), events: event(o, "end", note, actor) }), "admin");
    }
    if (a === "sync") {
      const p = o.paymentId ? docs.get(PAY, o.paymentId) : null;
      if (!p) fail(400, "Este anúncio ainda não tem Pix gerado.");
      await syncPayment(p);
      return detail(docs.get(ORD, o.id), "admin");
    }
    fail(400, "Ação inválida.");
  });

  // --- admin: pagamentos e relatório ---
  const inRange = (q) => (x) => (!q.get("from") || x.createdAt >= q.get("from")) && (!q.get("to") || x.createdAt.slice(0, 10) <= q.get("to"));
  r.get("/api/admin/advertising/payments", (ctx) => {
    requireAdmin(ctx);
    return docs.list(PAY).filter((p) => p.kind === "ad").filter(inRange(ctx.query)).map((p) => {
      const o = docs.get(ORD, p.refId);
      return { ...paymentOut(p), adsCount: (p.orderIds || [p.refId]).length, packageName: o?.packageName || p.packageName,
        title: o?.title || p.title, advertiser: o ? o.companyName || o.advertiserName : "", advertiserName: o?.advertiserName || "",
        companyName: o?.companyName || "", orderId: p.refId };
    });
  });
  r.get("/api/admin/advertising/report", (ctx) => {
    requireAdmin(ctx);
    const pays = docs.list(PAY).filter((p) => p.kind === "ad").filter(inRange(ctx.query));
    const ords = docs.list(ORD).filter(inRange(ctx.query)).map((o) => orderOut(o, "admin"));
    const ok = pays.filter((p) => p.status === "approved");
    const pend = pays.filter((p) => p.status === "pending");
    const c = (f) => ords.filter(f).length;
    return { revenueCents: ok.reduce((a, p) => a + p.amountCents, 0), confirmedPayments: ok.length,
      pendingPayments: pend.length, pendingCents: pend.reduce((a, p) => a + p.amountCents, 0),
      contracted: ords.length, approved: c((o) => ["scheduled", "active", "paused", "ended"].includes(o.displayStatus) && o.startsAt),
      pendingReview: c((o) => o.status === "pending_review"), changesRequested: c((o) => o.status === "changes_requested"),
      live: c((o) => o.displayStatus === "active"), scheduled: c((o) => o.displayStatus === "scheduled"),
      paused: c((o) => o.status === "paused"), ended: c((o) => o.displayStatus === "ended"),
      rejected: c((o) => o.status === "rejected"), awaitingPayment: c((o) => o.status === "awaiting_payment") };
  });
}

function pauseData(o, by) {
  const remainingMs = o.endsAt ? Math.max(0, new Date(o.endsAt).getTime() - Math.max(Date.now(), new Date(o.startsAt || Date.now()).getTime())) : null;
  return { status: "paused", pausedBy: by, pausedAt: now(), remainingMs, events: event(o, "pause") };
}
function resumeData(o) {
  const s = adSettings();
  const partial = { status: "approved", pausedBy: null, pausedAt: null, events: event(o, "resume") };
  if (s.pauseRule === "freeze" && o.remainingMs != null) {
    const start = new Date(Math.max(Date.now(), new Date(o.startsAt || Date.now()).getTime()));
    partial.endsAt = new Date(start.getTime() + o.remainingMs).toISOString();
  }
  partial.remainingMs = null;
  return partial;
}
