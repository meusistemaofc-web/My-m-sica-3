// Rádio ao Vivo: ouvintes, painel, playlists da rádio, programação automática, estúdio e bate-papo.
import { docs, users, kvGet, kvSet, now } from "../db.js";
import { fail } from "../http.js";
import { requireUser, requireAdmin } from "../auth.js";
import { uuid, coverUrl, songOut } from "../util.js";
import * as E from "../radio-engine.js";

const RPL = "radio-playlists";
const PRG = "radio-programs";
const RUN = "radio-runs";
const CHAT = "radio-chat";
const BAN = "radio-bans";

// ------------------------------------------------------------------ configurações
const DEFAULTS = {
  usersEnabled: false, access: "all", name: "Rádio My Music", program: "", host: "", coverKey: null,
  timezone: "America/Sao_Paulo", offlineMessage: "Estamos fora do ar no momento. Volte mais tarde!",
  chatEnabled: true, songRequests: false, shoutouts: false, countdownMinutes: 5,
  simultaneous: true, autoSwitch: "ask", shuffle: false,
};
export const radioSettings = () => ({ ...DEFAULTS, ...kvGet("radio:settings", {}) });
const settingsOut = (s = radioSettings()) => ({ ...s, coverUrl: coverUrl(s.coverKey),
  recording: false, scheduling: true, liveSend: false, maxMb: 20, maxSeconds: 600, texts: {} });
const allowedIds = () => kvGet("radio:access", []);
const automation = () => {
  const a = { paused: false, until: null, ...kvGet("radio:automation", {}) };
  if (a.paused && a.until && new Date(a.until) <= new Date()) return { paused: false, until: null };
  return a;
};

function canListen(u) {
  if (!u) return false;
  if (u.role === "admin") return true;
  const s = radioSettings();
  if (!s.usersEnabled) return false;
  return s.access !== "selected" || allowedIds().includes(u.id);
}

// ------------------------------------------------------------------ fuso horário
function tzOffsetMs(tz, date) {
  const parts = Object.fromEntries(new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit",
    day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(date).map((p) => [p.type, p.value]));
  const asUtc = Date.UTC(+parts.year, +parts.month - 1, +parts.day, +parts.hour % 24, +parts.minute, +parts.second);
  return asUtc - date.getTime();
}
/** "2026-11-04" + "08:00" no fuso → instante UTC (ms). */
function zoned(dateStr, timeStr, tz) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = timeStr.split(":").map(Number);
  let guess = Date.UTC(y, m - 1, d, hh, mm);
  for (let i = 0; i < 2; i++) guess = Date.UTC(y, m - 1, d, hh, mm) - tzOffsetMs(tz, new Date(guess));
  return guess;
}
const localDate = (ms, tz) => new Date(ms).toLocaleDateString("sv-SE", { timeZone: tz });
const addDays = (dateStr, n) => { const d = new Date(`${dateStr}T12:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const weekday = (dateStr) => new Date(`${dateStr}T12:00:00Z`).getUTCDay();

function windowFor(p, dateStr, tz) {
  const endDay = p.scheduleKind === "once" && p.endDate ? p.endDate : p.endTime <= p.startTime ? addDays(dateStr, 1) : dateStr;
  return { key: dateStr, start: zoned(dateStr, p.startTime, tz), end: zoned(endDay, p.endTime, tz) };
}
/** Janelas de horário do programa entre "from" e "to" (ms). */
function windows(p, from, to, tz) {
  if (p.scheduleKind === "once") {
    if (!p.date) return [];
    const w = windowFor(p, p.date, tz);
    return w.end > from && w.start < to ? [w] : [];
  }
  const out = [];
  let d = localDate(from - 2 * 86400e3, tz);
  const last = localDate(to, tz);
  for (let i = 0; i < 40 && d <= last; i++, d = addDays(d, 1)) {
    if (!(p.days || []).includes(weekday(d))) continue;
    if (p.date && d < p.date) continue;
    if (p.endDate && d > p.endDate) continue;
    const w = windowFor(p, d, tz);
    if (w.end > from && w.start < to) out.push(w);
  }
  return out;
}
const DAYS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
const br = (d) => (d || "").split("-").reverse().join("/");
function scheduleLabel(p) {
  const nd = p.endTime <= p.startTime ? " (dia seguinte)" : "";
  if (p.scheduleKind === "once") {
    return p.endDate && p.endDate !== p.date ? `${br(p.date)} ${p.startTime} até ${br(p.endDate)} ${p.endTime}` : `${br(p.date)} · ${p.startTime}–${p.endTime}${nd}`;
  }
  const k = [...(p.days || [])].sort().join(",");
  const days = k === "0,1,2,3,4,5,6" ? "Todos os dias" : k === "1,2,3,4,5" ? "Segunda a sexta" : k === "0,6" ? "Fins de semana" : [...(p.days || [])].sort().map((d) => DAYS[d]).join(", ");
  const range = p.date && p.endDate ? ` · de ${br(p.date)} até ${br(p.endDate)}` : p.date ? ` · a partir de ${br(p.date)}` : p.endDate ? ` · até ${br(p.endDate)}` : "";
  return `${days} · ${p.startTime}–${p.endTime}${nd}${range}`;
}

// ------------------------------------------------------------------ playlists e músicas
const sumDur = (ids) => ids.reduce((a, id) => a + (Number(docs.get("songs", id)?.duration) || 0), 0);
function trackInfo(ids) {
  return ids.map((id) => {
    const s = docs.get("songs", id);
    if (!s || s.status !== "ready") return { id, title: s?.title || "Música removida da biblioteca", artist: s?.artist || "", duration: s?.duration || 0, coverUrl: coverUrl(s?.coverKey), problem: "Esta música não está mais disponível na biblioteca." };
    const ok = /mpeg|mp3/i.test(s.mimeType || "") && E.songSegments(s);
    return { id, title: s.title, artist: s.artist, duration: s.duration, coverUrl: coverUrl(s.coverKey),
      problem: ok ? null : "Só músicas em MP3 podem tocar na programação automática." };
  });
}
const mainPlaylist = () => docs.list(RPL).find((p) => p.isMain) || null;
const liveStations = () => [...E.stations.values()];

function playlistOut(p) {
  const progs = docs.list(PRG).filter((g) => g.playlistId === p.id || (g.useMainPlaylist && p.isMain && !g.playlistId))
    .map((g) => ({ id: g.id, name: g.name, viaMain: g.playlistId !== p.id }));
  return { id: p.id, name: p.name, description: p.description || "", coverKey: p.coverKey || null, coverUrl: coverUrl(p.coverKey),
    playMode: p.playMode || "repeat", trackIds: p.trackIds || [], isMain: !!p.isMain, trackCount: (p.trackIds || []).length,
    durationSec: sumDur(p.trackIds || []), onAir: liveStations().some((s) => s.playlistId === p.id), programs: progs,
    createdAt: p.createdAt, updatedAt: p.updatedAt || p.createdAt };
}

function programTracks(p) {
  if (p.playlistId) { const pl = docs.get(RPL, p.playlistId); if (pl?.trackIds?.length) return { ids: pl.trackIds, source: "playlist", playlist: pl }; }
  if (p.useMainPlaylist) { const pl = mainPlaylist(); if (pl?.trackIds?.length) return { ids: pl.trackIds, source: "main", playlist: pl }; }
  return { ids: p.trackIds || [], source: "own", playlist: null };
}

function programOut(p) {
  const tz = radioSettings().timezone;
  const t = programTracks(p);
  const live = liveStations().find((s) => s.programId === p.id);
  const nowMs = Date.now();
  const ws = windows(p, nowMs, nowMs + 8 * 86400e3, tz);
  const w = ws.find((x) => x.end > nowMs) || null;
  const finished = p.scheduleKind === "once" && !w;
  return { ...p, coverUrl: coverUrl(p.coverKey), trackCount: t.ids.length, durationSec: sumDur(t.ids), source: t.source,
    playlist: t.playlist ? { id: t.playlist.id, name: t.playlist.name } : null, scheduleLabel: scheduleLabel(p),
    window: w ? { start: new Date(w.start).toISOString(), end: new Date(w.end).toISOString() } : null,
    status: live ? "live" : !p.active ? "paused" : finished ? "ended" : "scheduled" };
}

// ------------------------------------------------------------------ estações (saída para o app)
function stationSummary(st) {
  const np = E.nowPlaying(st);
  const song = np && docs.get("songs", np.songId);
  const s = radioSettings();
  return {
    id: st.id, sessionId: st.id, key: st.key, mode: st.mode, state: st.state === "starting" ? "live" : st.state,
    program: st.program || s.program || s.name, title: st.program, host: s.host || null,
    coverUrl: coverUrl(st.coverKey) || coverUrl(s.coverKey), programCoverUrl: coverUrl(st.coverKey),
    startedAt: st.startedAt, endsAt: st.endsAt || null, listeners: E.listenerCount(st.id), programId: st.programId || null,
    playlistUrl: `/api/radio/hls/${st.id}/live.m3u8`,
    nowPlaying: song ? { id: song.id, title: song.title, artist: song.artist, coverUrl: coverUrl(song.coverKey), duration: song.duration } : null,
    requestsEnabled: st.requestsEnabled !== false, clip: null, allowed: false, name: st.program || s.name,
  };
}

function queueTracks(st, current) {
  const ids = [...(current ? [current.id] : []), ...E.upNext(st, 3000).filter((id) => id !== current?.id)];
  return ids.map((id, index) => {
    const s = docs.get("songs", id);
    return { id, index, title: s?.title || "Música removida", artist: s?.artist || "", album: s?.album || "", duration: s?.duration || 0,
      coverUrl: coverUrl(s?.coverKey), radio: id === current?.id ? "playing" : "pending", problem: s ? null : "Esta música não está mais na biblioteca." };
  });
}

function stationDetail(st) {
  const base = stationSummary(st);
  const np = E.nowPlaying(st);
  const song = np && docs.get("songs", np.songId);
  const pl = st.playlistId ? docs.get(RPL, st.playlistId) : null;
  return { ...base, paused: !!st.paused, endMode: st.endMode, stopAt: st.stopAfterSong && !st.endsAt ? now() : null,
    repeat: st.repeat, shuffle: st.shuffle,
    current: song ? { id: song.id, title: song.title, artist: song.artist, coverUrl: coverUrl(song.coverKey), duration: song.duration, positionMs: np.positionMs } : null,
    upNext: E.upNext(st).map((id) => docs.get("songs", id)).filter(Boolean).map((s) => ({ id: s.id, title: s.title, artist: s.artist, duration: s.duration })),
    playlist: pl ? { id: pl.id, name: pl.name, main: !!pl.isMain } : null, clipOnAir: null, clipsWaiting: 0,
    queue: queueTracks(st, song), nextIndex: song ? 1 : 0, skipped: [] };
}

// ------------------------------------------------------------------ iniciar / encerrar
function logRun(st, reason) {
  if (!st.runId) return;
  docs.patch(RUN, st.runId, { status: "ended", endedAt: now(), endReason: reason });
}

function startProgram(p, { manual = false, force = false, windowEnd = null } = {}) {
  const s = radioSettings();
  const t = programTracks(p);
  if (!E.playableIds(t.ids).length) fail(400, "Esta programação não tem músicas em MP3 que possam tocar.");
  const existing = liveStations().find((x) => x.programId === p.id);
  if (existing) fail(409, "Esta programação já está no ar.");
  if (!s.simultaneous) {
    const other = liveStations()[0];
    if (other && !force) fail(409, `“${other.program}” está no ar. Confirme para encerrá-la e colocar esta programação no ar.`);
    if (other) E.endStation(other, "admin");
  }
  let endsAt = windowEnd;
  if (!endsAt) {
    const nowMs = Date.now();
    const w = windows(p, nowMs - 86400e3, nowMs + 86400e3, s.timezone).find((x) => x.start <= nowMs && x.end > nowMs);
    endsAt = w ? new Date(w.end).toISOString() : null;
    if (w) kvSet("radio:started", { ...kvGet("radio:started", {}), [p.id]: w.key });
  }
  const run = docs.put(RUN, uuid(), { programId: p.id, programName: p.name, status: "live", startedAt: now(), manual, createdAt: now() });
  const st = E.createAutoStation({ key: `p:${p.id}`, program: p.name, description: p.description, coverKey: p.coverKey, programId: p.id,
    playlistId: t.playlist?.id || null, trackIds: t.ids, endsAt, endMode: p.endMode, repeat: p.playMode === "repeat",
    shuffle: s.shuffle, requestsEnabled: p.requestsEnabled, manual, runId: run.id, onEnd: (x, why) => { logRun(x, why); persist(); } });
  if (!st) fail(400, "Nenhuma música desta programação pode tocar.");
  persist();
  return st;
}

function startPlaylist(pl, force) {
  const s = radioSettings();
  if (!E.playableIds(pl.trackIds || []).length) fail(400, "Esta playlist não tem músicas em MP3 que possam tocar.");
  if (liveStations().some((x) => x.playlistId === pl.id && !x.programId)) fail(409, "Esta playlist já está no ar.");
  if (!s.simultaneous) {
    const other = liveStations()[0];
    if (other && !force) fail(409, `“${other.program}” está no ar. Confirme para encerrá-la e colocar esta playlist no ar.`);
    if (other) E.endStation(other, "admin");
  }
  const st = E.createAutoStation({ key: `pl:${pl.id}`, program: pl.name, description: pl.description, coverKey: pl.coverKey, playlistId: pl.id,
    trackIds: pl.trackIds, repeat: (pl.playMode || "repeat") === "repeat", shuffle: s.shuffle, manual: true, onEnd: () => persist() });
  if (!st) fail(400, "Nenhuma música desta playlist pode tocar.");
  persist();
  return st;
}

/** Guarda as transmissões no ar para retomá-las se o servidor reiniciar. */
function persist() {
  kvSet("radio:live", liveStations().filter((s) => s.mode === "auto").map((s) => ({ programId: s.programId, playlistId: s.playlistId, endsAt: s.endsAt })));
}
function restore() {
  for (const item of kvGet("radio:live", [])) {
    try {
      if (item.programId) { const p = docs.get(PRG, item.programId); if (p) startProgram(p, { manual: true, force: true, windowEnd: item.endsAt }); }
      else if (item.playlistId) { const pl = docs.get(RPL, item.playlistId); if (pl) startPlaylist(pl, true); }
    } catch {}
  }
  persist();
}

// ------------------------------------------------------------------ agendador automático
function scheduler() {
  const s = radioSettings();
  const auto = automation();
  const nowMs = Date.now();
  const started = kvGet("radio:started", {});
  for (const p of docs.list(PRG)) {
    const live = liveStations().find((x) => x.programId === p.id);
    const ws = windows(p, nowMs - 86400e3, nowMs + 60e3, s.timezone);
    const cur = ws.find((w) => w.start <= nowMs && w.end > nowMs);
    if (live) {
      if (live.endsAt && nowMs >= new Date(live.endsAt).getTime() && live.endMode === "immediate") E.endStation(live, "schedule");
      continue;
    }
    if (!p.active || auto.paused || !cur || started[p.id] === cur.key) continue;
    if (nowMs - cur.start > 30 * 60e3 && p.scheduleKind !== "once") continue; // não começa um programa já quase no fim
    try {
      kvSet("radio:started", { ...kvGet("radio:started", {}), [p.id]: cur.key });
      if (!s.simultaneous && liveStations().length) {
        docs.put(RUN, uuid(), { programId: p.id, programName: p.name, status: "waiting", scheduledStart: new Date(cur.start).toISOString(),
          note: "Outra transmissão estava no ar.", createdAt: now() });
        continue;
      }
      startProgram(p, { windowEnd: new Date(cur.end).toISOString() });
    } catch (e) {
      docs.put(RUN, uuid(), { programId: p.id, programName: p.name, status: "failed", scheduledStart: new Date(cur.start).toISOString(),
        note: e.message, createdAt: now() });
    }
  }
}

// ------------------------------------------------------------------ informações para o ouvinte
function scheduleInfo() {
  const s = radioSettings();
  const nowMs = Date.now();
  const upcoming = [];
  for (const p of docs.list(PRG).filter((x) => x.active)) {
    for (const w of windows(p, nowMs, nowMs + 7 * 86400e3, s.timezone)) {
      if (w.start > nowMs) upcoming.push({ programId: p.id, name: p.name, startsAt: new Date(w.start).toISOString(), endsAt: new Date(w.end).toISOString(), coverUrl: coverUrl(p.coverKey) });
    }
  }
  upcoming.sort((a, b) => a.startsAt.localeCompare(b.startsAt));
  const lastRun = docs.list(RUN).find((r) => r.endedAt);
  return { next: automation().paused ? null : upcoming[0] || null, upcoming: automation().paused ? [] : upcoming.slice(0, 10),
    lastEnded: lastRun ? { name: lastRun.programName, endedAt: lastRun.endedAt } : null };
}

function listenerInfo(u) {
  const s = radioSettings();
  if (!canListen(u)) {
    return { available: false, reason: s.usersEnabled ? "account" : "disabled",
      message: s.usersEnabled ? "A Rádio ao Vivo ainda não está disponível para a sua conta." : null };
  }
  const list = liveStations().filter((x) => x.mode === "studio" ? x.segs.length > 0 : true).map(stationSummary);
  const first = list[0] || null;
  const ban = docs.get(BAN, String(u.id));
  return { available: true, settings: settingsOut(s), serverTime: now(), stations: list, session: first, state: first ? first.state : "off",
    schedule: scheduleInfo(), blockedUntil: ban && new Date(ban.until) > new Date() ? ban.until : null,
    offlineMessage: s.offlineMessage };
}

function adminOverview() {
  const s = radioSettings();
  const list = liveStations();
  const studio = list.find((x) => x.mode === "studio");
  const first = list[0] ? stationSummary(list[0]) : null;
  return { settings: settingsOut(s), allowedUsers: allowedIds().length, liveCount: list.length, pendingRequests: 0,
    session: first, studioLive: studio ? { startedAt: studio.startedAt, sessionId: studio.id } : null, automation: automation() };
}

// ------------------------------------------------------------------ bate-papo
let chatSeq = kvGet("radio:chatSeq", 0);
const lastSent = new Map();
function chatList(admin, after) {
  const all = docs.list(CHAT).sort((a, b) => a.n - b.n).slice(-300);
  const msgs = all.filter((m) => m.n > after && (admin || !m.deleted)).map((m) => ({ id: m.n, userId: m.userId, name: m.name, text: m.text,
    createdAt: m.createdAt, fromHost: !!m.fromHost, deleted: !!m.deleted }));
  const removed = all.filter((m) => m.deleted).map((m) => m.n);
  return { messages: msgs, removed };
}
function addChat(u, text, fromHost) {
  chatSeq += 1;
  kvSet("radio:chatSeq", chatSeq);
  const s = radioSettings();
  docs.put(CHAT, String(chatSeq), { n: chatSeq, userId: u.id, name: fromHost ? (s.host || s.name) : u.displayName, text, fromHost, createdAt: now() }, u.id);
  const all = docs.list(CHAT);
  if (all.length > 600) all.sort((a, b) => a.n - b.n).slice(0, all.length - 500).forEach((m) => docs.del(CHAT, m.id));
}

// ------------------------------------------------------------------ rotas
export function registerRadio(r) {
  // ---------- ouvintes ----------
  r.get("/api/radio", (ctx) => listenerInfo(requireUser(ctx)));
  r.get("/api/radio/public", () => {
    const s = radioSettings();
    if (!s.usersEnabled) return { available: false };
    const st = liveStations()[0];
    return { available: true, name: s.name, coverUrl: coverUrl(s.coverKey), live: st ? { program: st.program } : null,
      next: scheduleInfo().next, timezone: s.timezone };
  });
  r.post("/api/radio/presence", async (ctx) => {
    const u = requireUser(ctx);
    const b = await ctx.json();
    if (b.sessionId) E.touchListener(b.sessionId, u.id);
    return { ok: true };
  });

  // transmissão HLS
  r.get("/api/radio/hls/:id/live.m3u8", (ctx) => {
    const u = requireUser(ctx);
    if (!canListen(u)) fail(403, "A rádio não está disponível para a sua conta.");
    const body = E.playlistFor(ctx.params.id);
    if (!body) fail(404, "Esta transmissão foi encerrada.");
    E.touchListener(ctx.params.id, u.id);
    ctx.res.writeHead(200, { "Content-Type": "application/vnd.apple.mpegurl", "Cache-Control": "no-cache, no-store" });
    ctx.res.end(body);
    return ctx.HANDLED;
  });
  r.get("/api/radio/hls/:id/:seg", (ctx) => {
    requireUser(ctx);
    const m = /^seg-(\d+)\.mp3$/.exec(ctx.params.seg);
    if (!m) fail(404, "Trecho não encontrado.");
    const data = E.segmentFor(ctx.params.id, Number(m[1]));
    if (!data) fail(404, "Trecho não encontrado.");
    ctx.res.writeHead(200, { "Content-Type": "audio/mpeg", "Content-Length": data.length, "Cache-Control": "public, max-age=300" });
    ctx.res.end(data);
    return ctx.HANDLED;
  });

  // bate-papo
  r.get("/api/radio/chat", (ctx) => { const u = requireUser(ctx); if (!canListen(u)) fail(403, "Rádio indisponível."); return chatList(false, Number(ctx.query.get("after")) || 0); });
  r.post("/api/radio/chat", async (ctx) => {
    const u = requireUser(ctx);
    if (!canListen(u)) fail(403, "Rádio indisponível.");
    if (!radioSettings().chatEnabled) fail(403, "O bate-papo está desativado no momento.");
    const ban = docs.get(BAN, String(u.id));
    if (ban && new Date(ban.until) > new Date()) fail(403, "Você está temporariamente bloqueado no bate-papo.");
    const b = await ctx.json();
    const text = String(b.text || "").trim().slice(0, 300);
    if (!text) fail(400, "Escreva uma mensagem.");
    const last = lastSent.get(u.id);
    if (last && Date.now() - last.at < 3000) fail(429, "Espere alguns segundos antes de mandar outra mensagem.");
    if (last && last.text === text) fail(429, "Você já mandou esta mensagem.");
    lastSent.set(u.id, { at: Date.now(), text });
    addChat(u, text, false);
    return { ok: true };
  });
  r.delete("/api/radio/chat/:id", (ctx) => {
    const u = requireUser(ctx);
    const m = docs.get(CHAT, ctx.params.id);
    if (!m || m.userId !== u.id) fail(404, "Mensagem não encontrada.");
    docs.patch(CHAT, m.id, { deleted: true });
    return { ok: true };
  });

  // ---------- painel ----------
  r.get("/api/radio/admin", (ctx) => { requireAdmin(ctx); return adminOverview(); });
  r.put("/api/radio/admin/settings", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const allowed = Object.keys(DEFAULTS);
    const cur = kvGet("radio:settings", {});
    const next = { ...cur };
    for (const k of allowed) if (b[k] !== undefined) next[k] = b[k];
    if (next.access && !["all", "selected"].includes(next.access)) next.access = "all";
    if (b.timezone) { try { new Intl.DateTimeFormat("pt-BR", { timeZone: b.timezone }); } catch { fail(400, "Fuso horário inválido."); } }
    kvSet("radio:settings", next);
    if (b.shuffle !== undefined) for (const st of liveStations()) if (st.mode === "auto") st.shuffle = !!b.shuffle;
    return adminOverview();
  });
  r.put("/api/radio/admin/automation", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const until = b.paused && Number(b.hours) > 0 ? new Date(Date.now() + Number(b.hours) * 3600e3).toISOString() : null;
    kvSet("radio:automation", { paused: !!b.paused, until });
    return automation();
  });

  // estações no ar
  r.get("/api/radio/admin/auto", (ctx) => {
    requireAdmin(ctx);
    const want = ctx.query.get("sessao");
    const list = liveStations();
    const autoList = list.filter((s) => s.mode === "auto");
    const sel = autoList.find((s) => s.id === want) || autoList[0] || null;
    const studio = list.find((s) => s.mode === "studio");
    return { live: sel ? stationDetail(sel) : null, stations: list.map(stationSummary), simultaneous: radioSettings().simultaneous,
      studioLive: studio ? { startedAt: studio.startedAt, sessionId: studio.id } : null, automation: automation() };
  });
  r.post("/api/radio/admin/auto/:action", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const st = (b.sessionId && E.stations.get(b.sessionId)) || liveStations().find((s) => s.mode === "auto");
    if (!st || st.mode !== "auto") fail(404, "Nenhuma programação automática está no ar.");
    const a = ctx.params.action;
    if (a === "pause") E.pause(st);
    else if (a === "resume") E.resume(st);
    else if (a === "skip") E.skip(st);
    else if (a === "previous") E.previous(st);
    else if (a === "end") { E.endStation(st, "admin"); persist(); }
    else if (a === "play") { if (!b.songId) fail(400, "Escolha a música."); E.playNow(st, b.songId); }
    else if (a === "queue" || a === "reorder") {
      const cur = E.nowPlaying(st)?.songId;
      E.setQueue(st, (b.songIds || b.queue || []).filter((id) => id !== cur));
    } else if (a === "enqueue") {
      const cur = E.nowPlaying(st)?.songId;
      const upcoming = E.upNext(st, 3000).filter((id) => id !== cur);
      const add = (b.songIds || []).filter((id) => !upcoming.includes(id));
      E.setQueue(st, b.where === "end" ? [...upcoming, ...add] : [...add, ...upcoming]);
    }
    else if (a === "switch") {
      const pl = docs.get(RPL, b.playlistId);
      if (!pl || !E.playableIds(pl.trackIds || []).length) fail(400, "Esta playlist não tem músicas que possam tocar.");
      E.switchTracks(st, pl.trackIds, b.when === "now" ? "now" : "after", { playlistId: pl.id, repeat: (pl.playMode || "repeat") === "repeat" });
      persist();
    } else fail(400, "Comando inválido.");
    const list = liveStations();
    const sel = E.stations.get(st.id);
    return { live: sel ? stationDetail(sel) : null, stations: list.map(stationSummary), simultaneous: radioSettings().simultaneous,
      studioLive: null, automation: automation() };
  });

  // playlists da rádio
  r.get("/api/radio/admin/playlists", (ctx) => { requireAdmin(ctx); return docs.list(RPL).map(playlistOut).sort((a, b) => (b.isMain - a.isMain) || a.name.localeCompare(b.name)); });
  const plBody = (b) => {
    const out = {};
    if (b.name !== undefined) { out.name = String(b.name).trim().slice(0, 80); if (!out.name) fail(400, "Dê um nome à playlist."); }
    if (b.description !== undefined) out.description = String(b.description || "").slice(0, 400);
    if (b.coverKey !== undefined) out.coverKey = b.coverKey || null;
    if (b.playMode !== undefined) out.playMode = b.playMode === "once" ? "once" : "repeat";
    if (Array.isArray(b.trackIds)) out.trackIds = [...new Set(b.trackIds.map(String))].slice(0, 3000);
    if (b.isMain !== undefined) out.isMain = !!b.isMain;
    return out;
  };
  const setMain = (id, on) => { if (on) for (const p of docs.list(RPL)) if (p.id !== id && p.isMain) docs.patch(RPL, p.id, { isMain: false }); };
  const plDetail = (p) => ({ playlist: playlistOut(p), tracks: trackInfo(p.trackIds || []) });
  r.post("/api/radio/admin/playlists", async (ctx) => {
    requireAdmin(ctx);
    const data = plBody(await ctx.json());
    if (!data.name) fail(400, "Dê um nome à playlist.");
    const p = docs.put(RPL, uuid(), { playMode: "repeat", trackIds: [], ...data, createdAt: now() });
    setMain(p.id, p.isMain);
    return plDetail(p);
  });
  r.get("/api/radio/admin/playlists/:id", (ctx) => { requireAdmin(ctx); const p = docs.get(RPL, ctx.params.id); if (!p) fail(404, "Playlist não encontrada."); return plDetail(p); });
  r.patch("/api/radio/admin/playlists/:id", async (ctx) => {
    requireAdmin(ctx);
    const p = docs.patch(RPL, ctx.params.id, plBody(await ctx.json()));
    if (!p) fail(404, "Playlist não encontrada.");
    setMain(p.id, p.isMain);
    for (const st of liveStations()) if (st.playlistId === p.id && st.mode === "auto") { st.baseIds = p.trackIds; st.repeat = p.playMode !== "once"; }
    return plDetail(p);
  });
  r.delete("/api/radio/admin/playlists/:id", (ctx) => {
    requireAdmin(ctx);
    if (liveStations().some((s) => s.playlistId === ctx.params.id)) fail(409, "Esta playlist está no ar. Encerre a transmissão antes de excluir.");
    docs.del(RPL, ctx.params.id);
    for (const g of docs.list(PRG)) if (g.playlistId === ctx.params.id) docs.patch(PRG, g.id, { playlistId: null });
    return { ok: true };
  });
  r.put("/api/radio/admin/playlists/:id/main", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const p = docs.patch(RPL, ctx.params.id, { isMain: !!b.main });
    if (!p) fail(404, "Playlist não encontrada.");
    setMain(p.id, p.isMain);
    return playlistOut(p);
  });
  r.post("/api/radio/admin/playlists/:id/start", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const p = docs.get(RPL, ctx.params.id);
    if (!p) fail(404, "Playlist não encontrada.");
    const st = startPlaylist(p, !!b.force);
    return { ok: true, sessionId: st.id };
  });

  // programação
  const prgBody = (b) => {
    const out = {};
    const time = /^([01]\d|2[0-3]):([0-5]\d)$/, date = /^\d{4}-\d{2}-\d{2}$/;
    if (b.name !== undefined) out.name = String(b.name).trim().slice(0, 80);
    if (b.description !== undefined) out.description = String(b.description || "").slice(0, 400);
    if (b.coverKey !== undefined) out.coverKey = b.coverKey || null;
    if (b.active !== undefined) out.active = !!b.active;
    if (b.scheduleKind !== undefined) out.scheduleKind = b.scheduleKind === "once" ? "once" : "weekly";
    if (b.date !== undefined) out.date = b.date && date.test(b.date) ? b.date : null;
    if (b.endDate !== undefined) out.endDate = b.endDate && date.test(b.endDate) ? b.endDate : null;
    if (Array.isArray(b.days)) out.days = [...new Set(b.days.map(Number).filter((d) => d >= 0 && d <= 6))];
    if (b.startTime !== undefined) { if (!time.test(b.startTime)) fail(400, "Horário de início inválido."); out.startTime = b.startTime; }
    if (b.endTime !== undefined) { if (!time.test(b.endTime)) fail(400, "Horário de término inválido."); out.endTime = b.endTime; }
    if (Array.isArray(b.trackIds)) out.trackIds = [...new Set(b.trackIds.map(String))].slice(0, 3000);
    if (b.playMode !== undefined) out.playMode = b.playMode === "once" ? "once" : "repeat";
    if (b.endMode !== undefined) out.endMode = b.endMode === "immediate" ? "immediate" : "finish_song";
    if (b.requestsEnabled !== undefined) out.requestsEnabled = !!b.requestsEnabled;
    if (b.playlistId !== undefined) out.playlistId = b.playlistId || null;
    if (b.useMainPlaylist !== undefined) out.useMainPlaylist = !!b.useMainPlaylist;
    return out;
  };
  const prgDetail = (p) => ({ program: programOut(p), tracks: trackInfo(programTracks(p).ids) });
  r.get("/api/radio/admin/programs", (ctx) => {
    requireAdmin(ctx);
    const s = radioSettings();
    const nowMs = Date.now();
    const programs = docs.list(PRG).map(programOut);
    const agenda = [];
    for (const p of docs.list(PRG).filter((x) => x.active)) {
      for (const w of windows(p, nowMs, nowMs + 7 * 86400e3, s.timezone)) {
        const live = liveStations().some((x) => x.programId === p.id) && w.start <= nowMs;
        agenda.push({ programId: p.id, key: w.key, name: p.name, start: new Date(w.start).toISOString(), end: new Date(w.end).toISOString(),
          state: live ? "live" : automation().paused ? "suspended" : "scheduled", note: null });
      }
    }
    agenda.sort((a, b) => a.start.localeCompare(b.start));
    const nextA = agenda.find((a) => a.state === "scheduled" && a.start > now());
    const nextP = nextA ? docs.get(PRG, nextA.programId) : null;
    const liveIds = liveStations().map((x) => x.programId).filter(Boolean);
    return { programs, agenda, runs: docs.list(RUN).slice(0, 30), timezone: s.timezone, automation: automation(),
      nextProgram: nextP ? { id: nextP.id, name: nextP.name, coverUrl: coverUrl(nextP.coverKey), start: nextA.start, end: nextA.end } : null,
      liveProgramIds: liveIds, liveProgramId: liveIds[0] || null };
  });
  r.post("/api/radio/admin/programs", async (ctx) => {
    requireAdmin(ctx);
    const data = prgBody(await ctx.json());
    if (!data.name) fail(400, "Dê um nome à programação.");
    const p = docs.put(PRG, uuid(), { description: "", coverKey: null, active: true, scheduleKind: "weekly", date: null, endDate: null,
      days: [1, 2, 3, 4, 5], startTime: "08:00", endTime: "10:00", trackIds: [], playMode: "repeat", endMode: "finish_song",
      requestsEnabled: true, playlistId: null, useMainPlaylist: false, ...data, createdAt: now() });
    return prgDetail(p);
  });
  r.get("/api/radio/admin/programs/:id", (ctx) => { requireAdmin(ctx); const p = docs.get(PRG, ctx.params.id); if (!p) fail(404, "Programação não encontrada."); return prgDetail(p); });
  r.post("/api/radio/admin/programs/:id/prepare", (ctx) => { requireAdmin(ctx); const p = docs.get(PRG, ctx.params.id); if (!p) fail(404, "Programação não encontrada."); return prgDetail(p); });
  r.patch("/api/radio/admin/programs/:id", async (ctx) => {
    requireAdmin(ctx);
    const data = prgBody(await ctx.json());
    if (data.name === "") fail(400, "Dê um nome à programação.");
    const p = docs.patch(PRG, ctx.params.id, data);
    if (!p) fail(404, "Programação não encontrada.");
    const live = liveStations().find((x) => x.programId === p.id);
    if (live) { live.program = p.name; live.coverKey = p.coverKey; live.baseIds = programTracks(p).ids; }
    return prgDetail(p);
  });
  r.delete("/api/radio/admin/programs/:id", (ctx) => {
    requireAdmin(ctx);
    if (liveStations().some((x) => x.programId === ctx.params.id)) fail(409, "Esta programação está no ar. Encerre antes de excluir.");
    docs.del(PRG, ctx.params.id);
    return { ok: true };
  });
  r.post("/api/radio/admin/programs/:id/start", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const p = docs.get(PRG, ctx.params.id);
    if (!p) fail(404, "Programação não encontrada.");
    const st = startProgram(p, { manual: true, force: !!b.force });
    return { ok: true, sessionId: st.id };
  });

  // estúdio (microfone)
  r.post("/api/radio/admin/sessions", async (ctx) => {
    requireAdmin(ctx);
    const s = radioSettings();
    for (const st of liveStations()) if (st.mode === "studio") E.endStation(st, "admin");
    if (!s.simultaneous) for (const st of liveStations()) E.endStation(st, "studio");
    const st = E.createStudioStation({ program: s.program || s.name, coverKey: s.coverKey });
    persist();
    return { id: st.id, startedAt: st.startedAt };
  });
  r.put("/api/radio/admin/sessions/:id/segments/:seq", async (ctx) => {
    requireAdmin(ctx);
    const st = E.stations.get(ctx.params.id);
    if (!st || st.mode !== "studio") fail(409, "A transmissão foi encerrada pelo servidor.");
    const data = await ctx.raw(2 * 1024 * 1024);
    if (!data.length) fail(400, "Trecho vazio.");
    E.pushStudioSegment(st, Number(ctx.params.seq), data, Number(ctx.query.get("d")) || 2000, ctx.query.get("disc") === "1");
    return { listeners: E.listenerCount(st.id) };
  });
  r.put("/api/radio/admin/sessions/:id/now-playing", async (ctx) => {
    requireAdmin(ctx);
    const st = E.stations.get(ctx.params.id);
    if (!st) fail(404, "Transmissão não encontrada.");
    const b = await ctx.json();
    st.nowPlaying = b.songId || null;
    return { ok: true };
  });
  r.delete("/api/radio/admin/sessions/:id", (ctx) => {
    requireAdmin(ctx);
    const st = E.stations.get(ctx.params.id);
    if (st) E.endStation(st, "admin");
    return { ok: true };
  });

  // acesso
  const accessList = () => {
    const ids = new Set(allowedIds());
    const grants = kvGet("radio:accessAt", {});
    return { users: users.all().filter((u) => u.role !== "admin").map((u) => ({ id: u.id, name: u.displayName, displayName: u.displayName,
      email: u.email, grantedAt: ids.has(u.id) ? grants[u.id] || now() : null })) };
  };
  const setAccess = (ids) => {
    const grants = kvGet("radio:accessAt", {});
    for (const id of ids) grants[id] ||= now();
    kvSet("radio:accessAt", grants);
    kvSet("radio:access", [...new Set(ids.map(Number))]);
  };
  r.get("/api/radio/admin/access", (ctx) => { requireAdmin(ctx); return accessList(); });
  r.put("/api/radio/admin/access", async (ctx) => { requireAdmin(ctx); const b = await ctx.json(); setAccess(b.userIds || []); return accessList(); });
  r.post("/api/radio/admin/access/:id", (ctx) => { requireAdmin(ctx); setAccess([...allowedIds(), Number(ctx.params.id)]); return accessList(); });
  r.delete("/api/radio/admin/access/:id", (ctx) => { requireAdmin(ctx); setAccess(allowedIds().filter((x) => x !== Number(ctx.params.id))); return accessList(); });

  // moderação
  r.get("/api/radio/admin/chat", (ctx) => { requireAdmin(ctx); return chatList(true, Number(ctx.query.get("after")) || 0); });
  r.post("/api/radio/admin/chat", async (ctx) => {
    const u = requireAdmin(ctx);
    const b = await ctx.json();
    const text = String(b.text || "").trim().slice(0, 300);
    if (!text) fail(400, "Escreva uma mensagem.");
    addChat(u, text, true);
    return { ok: true };
  });
  r.delete("/api/radio/admin/chat/:id", (ctx) => { requireAdmin(ctx); docs.patch(CHAT, ctx.params.id, { deleted: true }); return { ok: true }; });
  r.get("/api/radio/admin/bans", (ctx) => {
    requireAdmin(ctx);
    return docs.list(BAN).filter((b) => new Date(b.until) > new Date()).map((b) => ({ userId: b.userId, name: b.name, until: b.until, reason: b.reason }));
  });
  r.post("/api/radio/admin/bans", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const u = users.byId(b.userId);
    if (!u) fail(404, "Usuário não encontrado.");
    if (u.role === "admin") fail(400, "Não é possível bloquear o administrador.");
    const until = new Date(Date.now() + Math.max(1, Number(b.minutes) || 15) * 60e3).toISOString();
    docs.put(BAN, String(u.id), { userId: u.id, name: u.displayName, until, reason: String(b.reason || "").slice(0, 200) });
    if (b.hideMessages) for (const m of docs.list(CHAT)) if (m.userId === u.id) docs.patch(CHAT, m.id, { deleted: true });
    return { ok: true, until };
  });
  r.delete("/api/radio/admin/bans/:userId", (ctx) => { requireAdmin(ctx); docs.del(BAN, ctx.params.userId); return { ok: true }; });

  // pedidos/presentes e áudios do estúdio: ainda não disponíveis nesta instalação
  r.get("/api/radio/admin/interactions/summary", (ctx) => { requireAdmin(ctx); return { pending: 0, unread: 0, total: 0 }; });

  setTimeout(restore, 1500).unref();
  setInterval(() => { try { scheduler(); } catch (e) { console.error("[rádio] agendador", e); } }, 15_000).unref();
}

export const radioHomeInfo = () => { const s = radioSettings(); return { usersEnabled: !!s.usersEnabled, access: s.access, available: true }; };
