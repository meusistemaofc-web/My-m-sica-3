import { docs, users, kvGet, kvSet, now } from "../db.js";
import { fail } from "../http.js";
import { requireUser, requireAdmin } from "../auth.js";
import { uuid } from "../util.js";
import {
  encrypt, mpConfig, mpPublicView, mpSave, mpDisconnect, mpCheck, mpAccountMethods, mpGetPayment, mpCancelPayment,
  checkoutDataOf, verifyWebhook, mpReady,
} from "../mercadopago.js";

const PAY = "payments";
const handlers = {}; // kind -> async (record, previousStatus) => void

/** Outros módulos (publicidade, planos) registram o que fazer quando um pagamento muda. */
export const onPaymentChange = (kind, fn) => { handlers[kind] = fn; };

export const METHODS = [
  { key: "pix", label: "Pix", note: "Aprovação em segundos. Usado também na publicidade paga." },
  { key: "credit_card", label: "Cartão de crédito", note: "Com parcelamento conforme as regras abaixo." },
  { key: "debit_card", label: "Cartão de débito", note: "Débito virtual (Caixa) e outros bancos compatíveis." },
  { key: "ticket", label: "Boleto", note: "Compensação em até 3 dias úteis." },
];
export function checkoutSettings() {
  return { methods: { pix: true, credit_card: true, debit_card: false, ticket: false }, maxInstallments: 12, minInstallmentCents: 500,
    ...kvGet("checkout:settings", {}) };
}
export function pixAvailability() {
  const c = mpConfig();
  if (!c || !c.accessTokenEnc) return { available: false, mode: null, reason: "O pagamento por Pix ainda não foi configurado pelo administrador (Mercado Pago)." };
  if (c.status !== "connected") return { available: false, mode: c.mode, reason: "A conexão com o Mercado Pago está com problema. O administrador precisa verificar as credenciais." };
  if (checkoutSettings().methods.pix === false) return { available: false, mode: c.mode, reason: "O Pix está desligado nas configurações de pagamento." };
  return { available: true, mode: c.mode, reason: null };
}

export function paymentOut(p) {
  if (!p) return null;
  const { raw, ...rest } = p;
  return rest;
}

/** Cria o registro local de um pagamento a partir da resposta do Mercado Pago. */
export function recordPayment({ kind, refId, userId, amountCents, mp, mode, channel = "pix", extra = {} }) {
  const rec = docs.put(PAY, uuid(), {
    kind, refId, userId, amountCents, currency: mp.currency_id || "BRL", mode, channel,
    mpPaymentId: String(mp.id), status: mp.status, statusDetail: mp.status_detail || null,
    paymentMethodId: mp.payment_method_id || null, paymentTypeId: mp.payment_type_id || null,
    cardLast4: mp.card?.last_four_digits || null, installments: mp.installments || null,
    checkoutData: checkoutDataOf(mp), processed: false, createdAt: now(), ...extra,
  }, userId);
  return rec;
}

/** Aplica o estado mais recente vindo do Mercado Pago e dispara as ações do módulo dono. */
export async function applyMpPayment(rec, mp) {
  const prev = rec.status;
  const updated = docs.patch(PAY, rec.id, {
    status: mp.status, statusDetail: mp.status_detail || null, paymentMethodId: mp.payment_method_id || rec.paymentMethodId,
    paymentTypeId: mp.payment_type_id || rec.paymentTypeId, cardLast4: mp.card?.last_four_digits || rec.cardLast4,
    approvedAt: mp.date_approved || rec.approvedAt || null, checkoutData: checkoutDataOf(mp) || rec.checkoutData, syncedAt: now(),
  });
  if (handlers[updated.kind]) await handlers[updated.kind](updated, prev);
  return docs.get(PAY, rec.id);
}

export async function syncPayment(rec) {
  if (!rec?.mpPaymentId) return rec;
  const mp = await mpGetPayment(rec.mpPaymentId);
  return applyMpPayment(rec, mp);
}

export function registerPayments(r) {
  // ---------- Configuração do Mercado Pago (admin) ----------
  r.get("/api/admin/payments", (ctx) => { requireAdmin(ctx); return mpPublicView(); });

  r.put("/api/admin/payments", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const mode = b.mode === "production" ? "production" : "test";
    const cur = mpConfig();
    const token = String(b.accessToken || "").trim();
    if (!token && !cur?.accessTokenEnc) fail(400, "Informe o Access Token.");
    if (token && mode === "production" && token.startsWith("TEST-")) fail(400, "Token de teste (TEST-) não funciona no modo Produção.");
    const partial = { mode, publicKey: String(b.publicKey || "").trim() };
    if (token) partial.accessTokenEnc = encrypt(token);
    if (b.webhookSecret) partial.webhookSecretEnc = encrypt(String(b.webhookSecret).trim());
    if (b.clearWebhookSecret) partial.webhookSecretEnc = null;
    mpSave(partial);
    if (token || !cur || cur.mode !== mode) mpSave(await mpCheck(token || undefined));
    return mpPublicView();
  });

  r.post("/api/admin/payments/test", async (ctx) => {
    requireAdmin(ctx);
    if (!mpConfig()?.accessTokenEnc) fail(400, "Salve as credenciais antes de testar.");
    mpSave(await mpCheck());
    return mpPublicView();
  });

  r.delete("/api/admin/payments", (ctx) => { requireAdmin(ctx); mpDisconnect(); return mpPublicView(); });

  // ---------- Formas de pagamento ----------
  const checkoutView = async () => {
    const view = mpPublicView();
    const onAccount = view.status === "connected" ? await mpAccountMethods() : null;
    return {
      connected: view.status === "connected", hasPublicKey: !!view.publicKey, accountError: view.configured && view.status !== "connected" ? view.lastError : null,
      settings: checkoutSettings(), maxAllowedInstallments: 12,
      methods: METHODS.map((m) => ({ ...m, compatible: true, onAccount: onAccount ? onAccount.has(m.key) : null })),
      plans: docs.list("plans").filter((p) => p.billing && p.billing !== "free").map((p) => ({ id: p.id, name: p.name, paymentMethods: p.paymentMethods ?? null })),
    };
  };
  r.get("/api/admin/payments/checkout", async (ctx) => { requireAdmin(ctx); return checkoutView(); });
  r.put("/api/admin/payments/checkout", async (ctx) => {
    requireAdmin(ctx);
    const b = await ctx.json();
    const s = b.settings || {};
    const cur = checkoutSettings();
    const methods = { ...cur.methods };
    for (const m of METHODS) if (typeof s.methods?.[m.key] === "boolean") methods[m.key] = s.methods[m.key];
    const maxInstallments = Math.min(12, Math.max(1, Number(s.maxInstallments) || cur.maxInstallments));
    const minInstallmentCents = Math.max(0, Number(s.minInstallmentCents) || 0);
    kvSet("checkout:settings", { methods, maxInstallments, minInstallmentCents });
    for (const [id, pm] of Object.entries(b.plans || {})) docs.patch("plans", id, { paymentMethods: pm });
    return checkoutView();
  });

  // ---------- Histórico (admin) ----------
  r.get("/api/admin/payments/history", (ctx) => {
    requireAdmin(ctx);
    const q = ctx.query;
    return docs.list(PAY).filter((p) => p.kind === "plan")
      .filter((p) => !q.get("status") || p.status === q.get("status"))
      .filter((p) => !q.get("planId") || p.planId === q.get("planId"))
      .filter((p) => !q.get("from") || p.createdAt >= q.get("from"))
      .filter((p) => !q.get("to") || p.createdAt.slice(0, 10) <= q.get("to"))
      .map((p) => {
        const u = users.byId(p.userId);
        return { ...paymentOut(p), user: u ? { id: u.id, name: u.displayName, email: u.email } : null,
          plan: { id: p.planId, name: p.planName || "Plano" }, discountCents: p.discountCents || 0 };
      });
  });

  // ---------- Pagamentos do usuário ----------
  const ownPayment = (ctx) => {
    const u = requireUser(ctx);
    const p = docs.get(PAY, ctx.params.id);
    if (!p || (p.userId !== u.id && u.role !== "admin")) fail(404, "Pagamento não encontrado.");
    return p;
  };
  r.get("/api/payments/:id", (ctx) => paymentOut(ownPayment(ctx)));
  r.post("/api/payments/:id/sync", async (ctx) => {
    const p = ownPayment(ctx);
    try { return { ...paymentOut(await syncPayment(p)), checked: true }; }
    catch (e) { return { ...paymentOut(p), checked: false, message: e.message }; }
  });
  r.post("/api/payments/:id/cancel", async (ctx) => {
    const p = ownPayment(ctx);
    if (!["pending", "in_process"].includes(p.status)) fail(409, "Este pagamento não pode mais ser cancelado.");
    const mp = await mpCancelPayment(p.mpPaymentId);
    return paymentOut(await applyMpPayment(p, mp));
  });

  // ---------- Notificações (webhook) do Mercado Pago ----------
  r.post("/api/payments/webhook", async (ctx) => {
    let body = {};
    try { body = await ctx.json(); } catch {}
    const type = ctx.query.get("type") || ctx.query.get("topic") || body.type || body.topic;
    const id = ctx.query.get("data.id") || body?.data?.id || (type === "payment" ? ctx.query.get("id") : null);
    if (type !== "payment" || !id) return { ok: true, ignored: true };
    if (!verifyWebhook(ctx.req, id)) fail(401, "Assinatura inválida.");
    if (!mpReady()) return { ok: true, ignored: true };
    try {
      const mp = await mpGetPayment(id);
      let rec = docs.list(PAY).find((p) => p.mpPaymentId === String(mp.id));
      if (!rec && mp.external_reference) rec = docs.get(PAY, mp.external_reference);
      if (rec) await applyMpPayment(rec, mp);
    } catch (e) {
      console.error("[webhook mercado pago]", e.message);
    }
    return { ok: true };
  });
  r.get("/api/payments/webhook", () => ({ ok: true }));
}

/** Verifica periodicamente os pagamentos pendentes (caso alguma notificação se perca). */
export function startPaymentWatcher() {
  const tick = async () => {
    if (!mpReady()) return;
    const pending = docs.list(PAY).filter((p) => ["pending", "in_process", "authorized"].includes(p.status) &&
      Date.now() - new Date(p.createdAt).getTime() < 3 * 86400e3);
    for (const p of pending.slice(0, 30)) { try { await syncPayment(p); } catch {} }
  };
  setInterval(() => tick().catch(() => {}), 120_000).unref();
}
