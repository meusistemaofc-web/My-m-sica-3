import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

// Carrega .env simples (KEY=VALUE) sem dependências.
const envFile = path.join(root, ".env");
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, "utf8").split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/.exec(line);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
  }
}

export const config = {
  root,
  port: Number(process.env.PORT || 3000),
  host: process.env.HOST || "0.0.0.0",
  publicDir: path.join(root, "public"),
  dataDir: path.resolve(root, process.env.DATA_DIR || "data"),
  publicUrl: (process.env.PUBLIC_URL || "").replace(/\/$/, ""),
  cookieSecure: process.env.COOKIE_SECURE === "true" ? true : process.env.COOKIE_SECURE === "false" ? false : "auto",
  ffmpegPath: process.env.FFMPEG_PATH || "ffmpeg",
  maxUploadBytes: 209715200, // 200 MB (mesmo limite do app)
  chunkSize: 4 * 1024 * 1024,
  adminEmail: "admin@gmail.com", // e-mail fixo usado pela tela de configuração inicial do app
};
