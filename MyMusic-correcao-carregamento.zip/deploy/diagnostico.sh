#!/usr/bin/env bash
# Mostra se o My Music está funcionando e onde está o problema.  Uso: sudo bash deploy/diagnostico.sh
cd "$(dirname "$0")/.."
PORTA="$(grep -E '^PORT=' .env 2>/dev/null | cut -d= -f2 || true)"; PORTA="${PORTA:-3000}"
echo "Node.js:   $(node -v 2>/dev/null || echo 'NÃO INSTALADO')"
echo "ffmpeg:    $(command -v ffmpeg >/dev/null && echo instalado || echo 'não instalado (só para converter MP4 em MP3)')"
echo "Serviço:   $(systemctl is-active mymusic 2>/dev/null)"
echo "Nginx:     $(systemctl is-active nginx 2>/dev/null)"
echo -n "App:       "; curl -fs "http://127.0.0.1:$PORTA/api/health" || echo "NÃO RESPONDE na porta $PORTA"
echo; echo "Espaço em disco:"; df -h . | tail -1
echo; node scripts/check.mjs | tail -3
echo; echo "Últimas mensagens do servidor:"; journalctl -u mymusic -n 15 --no-pager 2>/dev/null || true
