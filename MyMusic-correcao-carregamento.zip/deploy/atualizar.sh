#!/usr/bin/env bash
# Atualiza o My Music com a versão do GitHub, sem apagar músicas, usuários ou pagamentos (ficam em data/).
# Uso: sudo bash deploy/atualizar.sh
set -euo pipefail
cd "$(dirname "$0")/.."
echo "==> Backup de segurança antes de atualizar"
bash deploy/backup.sh || echo "   (backup não pôde ser feito; continuando)"
echo "==> Baixando a versão nova"
git config --global --add safe.directory "$(pwd)" 2>/dev/null || true
git pull --ff-only
echo "==> Conferindo os arquivos"
node scripts/check.mjs >/dev/null || { node scripts/check.mjs; echo "Atualização interrompida: corrija os problemas acima."; exit 1; }
systemctl restart mymusic
PORTA="$(grep -E '^PORT=' .env 2>/dev/null | cut -d= -f2 || true)"; PORTA="${PORTA:-3000}"
for i in $(seq 1 20); do curl -fs "http://127.0.0.1:$PORTA/api/health" >/dev/null && break; sleep 1; done
curl -fs "http://127.0.0.1:$PORTA/api/health" && echo && echo "✅ My Music atualizado." || { echo "❌ O serviço não voltou. Veja: journalctl -u mymusic -n 50"; exit 1; }
